
import React from 'react';
import { AppSection } from '../types';
import { Bell, UserCircle, ChevronDown } from 'lucide-react';
import { NAV_ITEMS } from '../constants';

interface HeaderProps {
  activeSection: AppSection;
}

export const Header: React.FC<HeaderProps> = ({ activeSection }) => {
  const currentLabel = NAV_ITEMS.find(i => i.id === activeSection)?.label || '概览';

  return (
    <header className="h-16 bg-white border-b border-slate-200 px-6 flex items-center justify-between z-10 sticky top-0">
      <div className="flex items-center gap-4">
        <h1 className="text-xl font-semibold text-slate-800">{currentLabel}</h1>
      </div>

      <div className="flex items-center gap-5">
        <button className="relative text-slate-500 hover:text-slate-800 transition-colors p-1.5 rounded-full hover:bg-slate-50">
          <Bell size={20} />
          <span className="absolute top-1 right-1 w-2 h-2 bg-rose-500 rounded-full border-2 border-white" />
        </button>
        <div className="flex items-center gap-3 pl-2 cursor-pointer hover:bg-slate-50 py-1 px-2 rounded-lg transition-colors group">
          <UserCircle size={28} className="text-slate-400 group-hover:text-blue-600 transition-colors" />
          <div className="hidden sm:flex flex-col">
            <span className="text-sm font-semibold text-slate-700 leading-none">张主任</span>
            <span className="text-[10px] text-slate-400 font-medium">高级行政岗</span>
          </div>
          <ChevronDown size={14} className="text-slate-400" />
        </div>
      </div>
    </header>
  );
};
