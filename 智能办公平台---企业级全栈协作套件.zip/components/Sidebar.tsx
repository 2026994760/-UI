
import React from 'react';
import { NAV_ITEMS } from '../constants';
import { AppSection } from '../types';
import { Sparkles, ChevronLeft, ChevronRight } from 'lucide-react';

interface SidebarProps {
  activeSection: AppSection;
  onSectionChange: (section: AppSection) => void;
  isCollapsed: boolean;
  onToggleCollapse: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ 
  activeSection, 
  onSectionChange, 
  isCollapsed, 
  onToggleCollapse 
}) => {
  return (
    <aside className={`bg-white border-r border-slate-200 flex flex-col h-full z-20 shadow-sm transition-all duration-300 relative ${isCollapsed ? 'w-20' : 'w-64'}`}>
      <button 
        onClick={onToggleCollapse}
        className="absolute -right-3 top-8 bg-white border border-slate-200 rounded-full p-1.5 text-slate-400 hover:text-blue-600 shadow-md z-30 transition-all hover:scale-110 active:scale-95"
      >
        {isCollapsed ? <ChevronRight size={14} /> : <ChevronLeft size={14} />}
      </button>

      <div className={`p-6 flex items-center ${isCollapsed ? 'justify-center' : 'gap-3'}`}>
        <div className="min-w-[40px] w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center text-white shadow-lg shadow-blue-200">
          <Sparkles size={24} />
        </div>
        {!isCollapsed && (
          <div className="flex flex-col animate-in fade-in slide-in-from-left-2 duration-300">
            <span className="font-bold text-lg text-slate-800 tracking-tight">智能办公</span>
            <span className="text-xs text-slate-400 font-medium uppercase tracking-wider">Enterprise Suite</span>
          </div>
        )}
      </div>

      <nav className="flex-1 px-4 py-4 space-y-1 overflow-y-auto scrollbar-hide">
        {NAV_ITEMS.map((item) => (
          <button
            key={item.id}
            onClick={() => onSectionChange(item.id)}
            title={isCollapsed ? item.label : ''}
            className={`w-full flex items-center rounded-lg text-sm font-medium transition-all duration-200 ${
              isCollapsed ? 'justify-center px-0 py-3' : 'gap-3 px-4 py-3'
            } ${
              activeSection === item.id
                ? 'bg-blue-50 text-blue-600 shadow-sm border border-blue-100'
                : 'text-slate-500 hover:bg-slate-100 hover:text-slate-700 border border-transparent'
            }`}
          >
            <div className="min-w-[20px]">{item.icon}</div>
            {!isCollapsed && <span className="animate-in fade-in slide-in-from-left-2 duration-300 truncate">{item.label}</span>}
          </button>
        ))}
      </nav>

      <div className="p-4 mt-auto">
        {isCollapsed ? (
          <div className="flex justify-center">
            <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          </div>
        ) : (
          <div className="bg-gradient-to-br from-slate-800 to-slate-900 rounded-xl p-4 text-white shadow-lg animate-in fade-in slide-in-from-bottom-2 duration-300">
            <div className="flex items-center gap-2 mb-2">
              <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span className="text-xs font-semibold text-slate-300">系统运行中</span>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed">
              智能办公助手 已连接
              <br />
              智算核心：已就绪
            </p>
          </div>
        )}
      </div>
    </aside>
  );
};
