
import React, { useState } from 'react';
import { Sparkles, Lock, Mail, ArrowRight, Loader2, ShieldCheck, Fingerprint, QrCode } from 'lucide-react';

interface LoginProps {
  onLogin: () => void;
}

export const Login: React.FC<LoginProps> = ({ onLogin }) => {
  const [email, setEmail] = useState('admin@enterprise.com');
  const [password, setPassword] = useState('password123');
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    // 模拟鉴权过程
    setTimeout(() => {
      setIsLoading(false);
      onLogin();
    }, 1200);
  };

  return (
    <div className="min-h-screen w-full bg-[#f8fafc] flex items-center justify-center p-6 relative overflow-hidden">
      {/* 动态背景装饰 */}
      <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-blue-100 rounded-full blur-[120px] opacity-60" />
      <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-indigo-100 rounded-full blur-[120px] opacity-60" />

      <div className="w-full max-w-[1100px] grid grid-cols-1 lg:grid-cols-2 bg-white rounded-[48px] shadow-2xl border border-slate-100 overflow-hidden relative z-10 animate-in fade-in zoom-in-95 duration-700">
        
        {/* 左侧品牌展示区 */}
        <div className="hidden lg:flex flex-col justify-between p-16 bg-slate-900 text-white relative overflow-hidden">
          <div className="absolute inset-0 opacity-10 pointer-events-none">
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_2px_2px,rgba(255,255,255,0.15)_1px,transparent_0)] bg-[size:32px_32px]" />
          </div>
          
          <div className="relative z-10">
            <div className="flex items-center gap-3 mb-10">
              <div className="w-12 h-12 bg-blue-600 rounded-2xl flex items-center justify-center text-white shadow-xl">
                <Sparkles size={28} />
              </div>
              <span className="text-2xl font-black tracking-tight">智能办公平台</span>
            </div>
            <h1 className="text-5xl font-black leading-tight mb-6">
              重构未来的<br />
              <span className="text-blue-500">企业级协作</span>
            </h1>
            <p className="text-slate-400 text-lg font-medium leading-relaxed max-w-sm">
              融合最新 智能办公助手 模型，为您的团队提供超越想象的智能化公文写作与数据洞察。
            </p>
          </div>

          <div className="relative z-10 flex items-center gap-6">
            <div className="flex -space-x-3">
              {[1, 2, 3, 4].map(i => (
                <div key={i} className="w-10 h-10 rounded-full border-2 border-slate-900 bg-slate-800 flex items-center justify-center text-[10px] font-bold">U{i}</div>
              ))}
            </div>
            <span className="text-sm text-slate-400 font-bold">已有 500+ 企业部署</span>
          </div>
        </div>

        {/* 右侧登录表单区 */}
        <div className="p-12 lg:p-20 flex flex-col justify-center">
          <div className="mb-10">
            <h2 className="text-3xl font-black text-slate-800 mb-2">欢迎回来</h2>
            <p className="text-slate-400 font-medium">请登录您的企业账户以继续工作</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-2">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-2 px-1">
                <Mail size={12}/> 电子邮箱 / 账号
              </label>
              <div className="relative">
                <input 
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full px-6 py-4 bg-slate-50 border border-slate-100 rounded-2xl text-sm font-bold focus:ring-4 focus:ring-blue-500/10 outline-none transition-all placeholder:text-slate-300"
                  placeholder="name@company.com"
                  required
                />
              </div>
            </div>

            <div className="space-y-2">
              <div className="flex justify-between items-center px-1">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-2">
                  <Lock size={12}/> 访问密码
                </label>
                <button type="button" className="text-[10px] font-black text-blue-600 uppercase hover:underline">忘记密码?</button>
              </div>
              <div className="relative">
                <input 
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full px-6 py-4 bg-slate-50 border border-slate-100 rounded-2xl text-sm font-bold focus:ring-4 focus:ring-blue-500/10 outline-none transition-all placeholder:text-slate-300"
                  placeholder="••••••••"
                  required
                />
              </div>
            </div>

            <div className="flex items-center gap-3 px-1">
              <input type="checkbox" id="remember" className="w-4 h-4 rounded border-slate-200 text-blue-600 focus:ring-blue-500" />
              <label htmlFor="remember" className="text-xs font-bold text-slate-500 cursor-pointer">保持登录状态</label>
            </div>

            <button 
              type="submit"
              disabled={isLoading}
              className="w-full py-5 bg-blue-600 text-white rounded-[20px] font-black text-sm shadow-2xl shadow-blue-100 hover:bg-blue-700 transition-all flex items-center justify-center gap-3 disabled:opacity-70"
            >
              {isLoading ? (
                <>
                  <Loader2 size={20} className="animate-spin" />
                  验证中...
                </>
              ) : (
                <>
                  登录系统 <ArrowRight size={20} />
                </>
              )}
            </button>
          </form>

          <div className="mt-12">
            <div className="relative flex items-center justify-center mb-8">
              <div className="absolute inset-0 flex items-center"><div className="w-full border-t border-slate-100"></div></div>
              <span className="relative bg-white px-4 text-[10px] font-black text-slate-300 uppercase tracking-widest">其他登录方式</span>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <button className="flex items-center justify-center gap-3 py-4 border border-slate-100 rounded-2xl hover:bg-slate-50 transition-all text-xs font-bold text-slate-600">
                <QrCode size={18} className="text-slate-400" /> 扫码登录
              </button>
              <button className="flex items-center justify-center gap-3 py-4 border border-slate-100 rounded-2xl hover:bg-slate-50 transition-all text-xs font-bold text-slate-600">
                <Fingerprint size={18} className="text-slate-400" /> 生物识别
              </button>
            </div>
          </div>

          <div className="mt-auto pt-10 flex items-center justify-center gap-6">
            <div className="flex items-center gap-2 text-[9px] font-black text-slate-300 uppercase tracking-tighter">
              <ShieldCheck size={12} /> SSL 加密保护
            </div>
            <div className="w-px h-3 bg-slate-100" />
            <span className="text-[9px] font-black text-slate-300 uppercase tracking-tighter">企业版 v3.2.0</span>
          </div>
        </div>
      </div>
    </div>
  );
};
