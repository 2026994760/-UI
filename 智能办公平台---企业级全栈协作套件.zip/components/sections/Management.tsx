
import React, { useState } from 'react';
import { 
  Users, 
  ShieldCheck, 
  ClipboardList, 
  ChevronRight, 
  ChevronLeft,
  Plus, 
  Trash2, 
  CheckCircle2,
  Cpu,
  AudioLines,
  MessageSquareQuote,
  Network,
  Globe,
  Lock,
  Edit3,
  Sliders,
  Activity,
  UserPlus,
  ShieldAlert,
  KeyRound,
  Building2,
  X,
  History,
  Search,
  MousePointer2,
  Info
} from 'lucide-react';
import { db_models, db_users } from '../../mockApi.ts';

type ModelType = 'ASR' | 'LLM' | 'EMBEDDING';

interface ModelConfig {
  id: string;
  type: ModelType;
  name: string;
  url: string;
  apiKey: string;
  modelName: string;
  temperature?: number;
  maxTokens?: number;
  topP?: number;
  contextTurns?: number;
  status: 'active' | 'error';
}

interface UserRecord {
  id: string;
  name: string;
  dept: string;
  role: string;
  permissions: string[];
  status: '在线' | '离线';
  lastLogin: string;
}

interface AuditLog {
  id: string;
  time: string;
  user: string;
  module: '系统管理' | '用户权限' | '模型算力' | '公文会议';
  action: string;
  details: string;
  severity: 'info' | 'warning' | 'danger';
}

const DEPARTMENTS = ['总经办', '行政部', '财务部', '数字化部', '法务部', '市场部', '技术部'];
const PERMISSIONS_LIST = [
  { id: 'write', label: '公文撰写' },
  { id: 'minutes', label: '会议解析' },
  { id: 'kb_manage', label: '知识库管理' },
  { id: 'bi_access', label: 'BI分析权' },
  { id: 'sys_admin', label: '系统管理' }
];

const AUDIT_MODULES = [
  { id: 'ALL', label: '全量流水' },
  { id: '系统管理', label: '系统配置' },
  { id: '用户权限', label: '人员权限' },
  { id: '模型算力', label: '算力模型' },
  { id: '公文会议', label: '业务操作' },
];

export const Management: React.FC = () => {
  const [view, setView] = useState<'overview' | 'models' | 'users' | 'audit'>('overview');
  const [activeModelType, setActiveModelType] = useState<ModelType>('LLM');
  const [activeAuditTab, setActiveAuditTab] = useState<string>('ALL');
  
  const [models, setModels] = useState<ModelConfig[]>(db_models.map(m => ({...m, apiKey: 'sk-proj-****', maxTokens: 4096, contextTurns: 10} as any)));
  const [editingModel, setEditingModel] = useState<ModelConfig | null>(null);
  const [showModelModal, setShowModelModal] = useState(false);

  const [users, setUsers] = useState<UserRecord[]>(db_users.map(u => ({...u, lastLogin: '刚刚'} as any)));
  const [showUserModal, setShowUserModal] = useState(false);
  const [newUser, setNewUser] = useState<Partial<UserRecord>>({
    name: '',
    dept: '行政部',
    role: '员工',
    permissions: [],
  });

  const [auditLogs] = useState<AuditLog[]>([
    { id: 'l1', time: '2024-11-24 10:24:15', user: '陈建国', module: '模型算力', action: '模型参数变更', details: '修改了 [智算核心 A] 的推理温度为 0.8', severity: 'info' },
    { id: 'l2', time: '2024-11-24 09:45:02', user: '张主任', module: '用户权限', action: '新增内部成员', details: '添加了新用户 [张小强]，所属部门：行政部', severity: 'info' },
    { id: 'l3', time: '2024-11-24 09:12:30', user: '系统', module: '系统管理', action: '安全策略更新', details: '强制开启全员多因素身份验证 (MFA)', severity: 'warning' },
    { id: 'l4', time: '2024-11-24 08:30:11', user: '王伟', module: '公文会议', action: '敏感文档导出', details: '导出了机密级文档：[2025年集团战略规划]', severity: 'danger' },
  ]);

  const filteredLogs = auditLogs.filter(log => activeAuditTab === 'ALL' || log.module === activeAuditTab);

  const handleSaveModel = (e: React.FormEvent) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget as HTMLFormElement);
    const data: any = Object.fromEntries(formData.entries());
    
    if (editingModel) {
      setModels(models.map(m => m.id === editingModel.id ? { ...m, ...data, type: activeModelType } : m));
    } else {
      setModels([...models, { 
        ...data, 
        id: `m-${Date.now()}`, 
        type: activeModelType, 
        status: 'active',
        temperature: Number(data.temperature),
        maxTokens: Number(data.maxTokens),
        contextTurns: Number(data.contextTurns)
      }]);
    }
    setShowModelModal(false);
    setEditingModel(null);
  };

  const handleSaveUser = () => {
    if (!newUser.name) return;
    const user: UserRecord = {
      id: `u-${Date.now()}`,
      name: newUser.name || '',
      dept: newUser.dept || '行政部',
      role: newUser.role || '员工',
      permissions: newUser.permissions || [],
      status: '离线',
      lastLogin: '从未登录'
    };
    setUsers([user, ...users]);
    setShowUserModal(false);
    setNewUser({ name: '', dept: '行政部', role: '员工', permissions: [] });
  };

  const renderOverview = () => (
    <div className="space-y-6 animate-in fade-in duration-500">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div onClick={() => setView('models')} className="group bg-slate-900 rounded-[40px] p-10 flex flex-col justify-between cursor-pointer hover:shadow-2xl hover:shadow-blue-500/10 transition-all border border-slate-800 relative overflow-hidden h-[360px]">
          <div className="absolute top-0 right-0 p-12 opacity-10 group-hover:opacity-20 transition-opacity">
            <Cpu size={140} className="text-blue-500" />
          </div>
          <div className="relative z-10">
            <div className="flex items-center gap-4 mb-8">
              <div className="p-4 bg-blue-600 rounded-2xl text-white shadow-xl shadow-blue-500/20">
                <Cpu size={32} />
              </div>
              <div>
                <h3 className="text-2xl font-black text-white">模型算力中心</h3>
                <p className="text-slate-400 text-sm font-medium mt-1 uppercase tracking-widest">Model Processing Unit</p>
              </div>
            </div>
            <div className="grid grid-cols-3 gap-6">
               <div className="bg-white/5 rounded-2xl p-4 border border-white/5">
                 <p className="text-[10px] font-bold text-slate-500 uppercase tracking-tighter">LLM 引擎</p>
                 <p className="text-xl font-black text-white mt-1">{models.filter(m=>m.type==='LLM').length} 组</p>
               </div>
               <div className="bg-white/5 rounded-2xl p-4 border border-white/5">
                 <p className="text-[10px] font-bold text-slate-500 uppercase tracking-tighter">ASR 并发</p>
                 <p className="text-xl font-black text-white mt-1">128 线</p>
               </div>
               <div className="bg-white/5 rounded-2xl p-4 border border-white/5">
                 <p className="text-[10px] font-bold text-slate-500 uppercase tracking-tighter">平均延迟</p>
                 <p className="text-xl font-black text-emerald-400 mt-1">2ms</p>
               </div>
            </div>
          </div>
          <div className="relative z-10 mt-10">
             <span className="text-xs font-bold text-blue-400 flex items-center gap-2 underline underline-offset-4">管理 ASR / LLM / EMBEDDING <ChevronRight size={14}/></span>
          </div>
        </div>

        <div onClick={() => setView('users')} className="group bg-white rounded-[40px] p-10 flex flex-col justify-between cursor-pointer hover:shadow-2xl hover:shadow-indigo-500/5 transition-all border border-slate-100 relative overflow-hidden h-[360px]">
          <div className="absolute top-0 right-0 p-12 opacity-5 group-hover:opacity-10 transition-opacity">
            <Users size={140} className="text-indigo-600" />
          </div>
          <div className="relative z-10">
            <div className="flex items-center gap-4 mb-8">
              <div className="p-4 bg-indigo-50 text-indigo-600 rounded-2xl">
                <Users size={32} />
              </div>
              <div>
                <h3 className="text-2xl font-black text-slate-800">用户与权限</h3>
                <p className="text-slate-400 text-sm font-medium mt-1 uppercase tracking-widest">Identity & Access Management</p>
              </div>
            </div>
            <div className="flex items-center gap-6">
               <div className="flex -space-x-3">
                 {users.map((u, i) => (
                   <div key={i} className="w-10 h-10 rounded-full border-4 border-white bg-slate-100 flex items-center justify-center text-xs font-black text-slate-500 shadow-sm">{u.name[0]}</div>
                 ))}
               </div>
               <span className="text-sm font-bold text-slate-400">已有 {users.length} 名内部成员</span>
            </div>
          </div>
          <div className="relative z-10 mt-10 flex items-center justify-between">
             <span className="text-xs font-bold text-indigo-600 flex items-center gap-2 underline underline-offset-4">新增用户与配置权限矩阵 <ChevronRight size={14}/></span>
             <div className="px-4 py-2 bg-indigo-50 text-indigo-600 rounded-xl text-[10px] font-black uppercase tracking-widest flex items-center gap-2">
                <ShieldCheck size={14}/> 加密保护中
             </div>
          </div>
        </div>
      </div>
    </div>
  );

  const renderModels = () => (
    <div className="space-y-8 animate-in slide-in-from-right-4 duration-500">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-6">
          <button onClick={() => setView('overview')} className="p-3 bg-white border border-slate-200 text-slate-400 rounded-2xl hover:text-blue-600 transition-all shadow-sm"><ChevronLeft size={24}/></button>
          <h2 className="text-2xl font-black text-slate-800">模型算力管理</h2>
        </div>
        <button onClick={() => { setEditingModel(null); setShowModelModal(true); }} className="flex items-center gap-3 px-8 py-4 bg-blue-600 text-white rounded-[24px] text-sm font-black shadow-2xl hover:bg-blue-700 transition-all">
          <Plus size={18} /> 配置新模型
        </button>
      </div>
      <div className="bg-white rounded-[40px] border border-slate-100 p-8 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {models.filter(m => m.type === activeModelType).map(model => (
          <div key={model.id} className="bg-white rounded-[32px] border border-slate-100 p-8 shadow-sm hover:shadow-xl hover:border-blue-400/30 transition-all group relative">
             <div className="flex items-center justify-between mb-6">
                <div className="w-12 h-12 bg-slate-50 text-slate-800 rounded-2xl flex items-center justify-center group-hover:bg-blue-600 group-hover:text-white transition-all shadow-inner">
                  {model.type === 'LLM' && <MessageSquareQuote size={24}/>}
                  {model.type === 'ASR' && <AudioLines size={24}/>}
                  {model.type === 'EMBEDDING' && <Network size={24}/>}
                </div>
                <div className="flex gap-2">
                   <button onClick={() => { setEditingModel(model); setShowModelModal(true); }} className="p-2 text-slate-300 hover:text-blue-600 hover:bg-blue-50 rounded-xl transition-all"><Edit3 size={16}/></button>
                   <button onClick={() => setModels(models.filter(m => m.id !== model.id))} className="p-2 text-slate-300 hover:text-rose-600 hover:bg-rose-50 rounded-xl transition-all"><Trash2 size={16}/></button>
                </div>
             </div>
             <h4 className="text-lg font-black text-slate-800 truncate mb-1">{model.name}</h4>
             <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">{model.modelName}</p>
             <div className="mt-8 space-y-3 pt-6 border-t border-slate-50 text-[10px] font-bold text-slate-500">
                <div className="flex items-center gap-2 text-emerald-500 mt-2"><CheckCircle2 size={12}/> 节点正常 (Local Cache)</div>
             </div>
          </div>
        ))}
      </div>
    </div>
  );

  return (
    <div className="h-full">
      {view === 'overview' && renderOverview()}
      {view === 'models' && renderModels()}
    </div>
  );
};
