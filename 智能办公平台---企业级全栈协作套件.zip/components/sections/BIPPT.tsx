
import React, { useState } from 'react';
import { 
  BarChart3, Presentation, Table as TableIcon, Upload, Play, Download, Settings2, Sparkles, Layout, 
  Plus, Trash2, ChevronRight, ChevronLeft, FileText, Palette, Type, Maximize2, ArrowRight, 
  TrendingUp, Edit3, X, FileBarChart, FileArchive, Info, CheckCircle2, FileStack, FileEdit, Save,
  ArrowLeft, Share2, Printer
} from 'lucide-react';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer
} from 'recharts';

interface DataPoint {
  id: string;
  name: string;
  value: number;
}

interface PPTSlide {
  id: string;
  title: string;
  content: string;
  type: 'text' | 'chart';
}

export const BIPPT: React.FC = () => {
  const [view, setView] = useState<'input' | 'bi-preview' | 'ppt-preview'>('input');
  const [inputData, setInputData] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [dataPoints, setDataPoints] = useState<DataPoint[]>([
    { id: '1', name: '行政', value: 400 },
    { id: '2', name: '市场', value: 300 },
    { id: '3', name: '技术', value: 500 },
    { id: '4', name: '销售', value: 200 },
  ]);
  const [slides, setSlides] = useState<PPTSlide[]>([
    { id: 's1', title: 'Q3季度行政开支分析', content: '核心汇报点：行政部开支占总预算 25%，同比增长 2%。', type: 'text' },
    { id: 's2', title: '各部门效能对比图', content: '技术研发效能最高。', type: 'chart' }
  ]);
  const [activeSlideIdx, setActiveSlideIdx] = useState(0);

  const startBI = () => {
    setIsGenerating(true);
    setTimeout(() => { setIsGenerating(false); setView('bi-preview'); }, 1200);
  };

  const startPPT = () => {
    setIsGenerating(true);
    setTimeout(() => { setIsGenerating(false); setView('ppt-preview'); }, 1500);
  };

  const saveSlideChanges = (newTitle: string, newContent: string) => {
    const newSlides = [...slides];
    newSlides[activeSlideIdx] = { ...newSlides[activeSlideIdx], title: newTitle, content: newContent };
    setSlides(newSlides);
  };

  const renderInputView = () => (
    <div className="h-full flex flex-col max-w-5xl mx-auto py-10 animate-in fade-in duration-500">
      <div className="text-center mb-12">
         <h2 className="text-4xl font-black text-slate-800 tracking-tight mb-4">BI & PPT 智能创作协同</h2>
         <p className="text-slate-400 font-medium">从底层数据到专业汇报，全链路 AI 极速生成</p>
      </div>

      <div className="flex-1 bg-white p-10 rounded-[48px] border border-slate-200 shadow-sm flex flex-col gap-8 transition-all hover:border-blue-200">
          <div className="flex-1 flex flex-col gap-4">
             <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-400 uppercase tracking-widest flex items-center gap-2">
                  <FileEdit size={16}/> 指令描述与数据源
                </span>
                <div className="flex gap-2">
                   <button className="text-[10px] bg-slate-100 px-3 py-1 rounded-full text-slate-500 font-bold">导入 Excel</button>
                   <button className="text-[10px] bg-slate-100 px-3 py-1 rounded-full text-slate-500 font-bold">历史指令</button>
                </div>
             </div>
             <textarea 
               value={inputData}
               onChange={(e) => setInputData(e.target.value)}
               placeholder="输入您的业务需求，例如：分析过去半年的行政、人力成本支出，并生成一份用于月度经营会议的汇报 PPT..."
               className="flex-1 w-full p-8 bg-slate-50 border border-slate-100 rounded-[32px] text-xl focus:ring-8 focus:ring-blue-500/5 outline-none resize-none transition-all placeholder:text-slate-300 leading-relaxed font-medium"
             />
          </div>

          <div className="grid grid-cols-2 gap-6">
             <button onClick={startBI} className="group p-8 bg-slate-900 text-white rounded-[32px] flex items-center justify-between hover:bg-slate-800 transition-all shadow-2xl">
                <div>
                   <h3 className="text-xl font-bold flex items-center gap-2"><BarChart3 size={24}/> 智能 BI 看板</h3>
                   <p className="text-xs text-slate-400 mt-1">数据清洗、聚类分析、多维图表展示</p>
                </div>
                <ArrowRight className="group-hover:translate-x-2 transition-transform" />
             </button>
             <button onClick={startPPT} className="group p-8 bg-blue-600 text-white rounded-[32px] flex items-center justify-between hover:bg-blue-700 transition-all shadow-2xl shadow-blue-100">
                <div>
                   <h3 className="text-xl font-bold flex items-center gap-2"><Presentation size={24}/> 专业汇报 PPT</h3>
                   <p className="text-xs text-blue-200 mt-1">幻灯片排版、自动配图、演讲稿大纲</p>
                </div>
                <ArrowRight className="group-hover:translate-x-2 transition-transform" />
             </button>
          </div>
      </div>
    </div>
  );

  const renderBIPreview = () => (
    <div className="h-full flex flex-col gap-6 animate-in slide-in-from-bottom-8 duration-500">
      <div className="flex items-center justify-between bg-white px-8 py-4 rounded-[28px] border border-slate-200 shadow-sm shrink-0">
        <div className="flex items-center gap-4">
          <button onClick={() => setView('input')} className="p-2.5 bg-slate-50 text-slate-500 rounded-xl hover:bg-slate-100"><ArrowLeft size={20}/></button>
          <div>
            <h3 className="text-sm font-bold text-slate-800">BI 可视化分析看板</h3>
            <p className="text-[10px] text-slate-400 font-bold tracking-widest uppercase">Data Intelligence Canvas</p>
          </div>
        </div>
        <div className="flex gap-2">
          <button className="flex items-center gap-2 px-5 py-2.5 bg-slate-100 text-slate-600 rounded-xl text-xs font-bold hover:bg-slate-200">
            <Download size={14}/> 导出报表 (Excel)
          </button>
          <button onClick={() => setView('ppt-preview')} className="flex items-center gap-2 px-6 py-2.5 bg-blue-600 text-white rounded-xl text-xs font-bold hover:bg-blue-700 shadow-lg shadow-blue-100">
            生成汇报 PPT <ChevronRight size={14}/>
          </button>
        </div>
      </div>

      <div className="flex-1 grid grid-cols-3 gap-6">
        <div className="col-span-2 bg-white rounded-[40px] border border-slate-200 p-10 flex flex-col">
          <div className="flex items-center justify-between mb-10">
             <h4 className="text-lg font-bold text-slate-800">部门支出多维透视</h4>
             <div className="flex gap-1 bg-slate-50 p-1 rounded-xl">
               <button className="px-4 py-1.5 bg-white shadow-sm rounded-lg text-xs font-bold text-blue-600">柱状图</button>
               <button className="px-4 py-1.5 text-xs font-bold text-slate-400">饼图</button>
             </div>
          </div>
          <div className="flex-1 min-h-[400px]">
            <ResponsiveContainer width="100%" height="100%">
               <BarChart data={dataPoints}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                  <XAxis dataKey="name" axisLine={false} tickLine={false} />
                  <Tooltip cursor={{fill: '#f8fafc'}} contentStyle={{borderRadius: '16px', border: 'none', boxShadow: '0 20px 25px -5px rgb(0 0 0 / 0.1)'}} />
                  <Bar dataKey="value" fill="#2563eb" radius={[12, 12, 0, 0]} barSize={60} />
               </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
        <div className="bg-white rounded-[40px] border border-slate-200 p-8 flex flex-col">
           <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-6">数据异常探测</h4>
           <div className="space-y-4">
              {[
                { label: '技术部', info: '支出超出预算 15%', status: 'warning' },
                { label: '行政部', info: '费用环比下降 4%', status: 'success' }
              ].map((item, i) => (
                <div key={i} className={`p-5 rounded-3xl border ${item.status === 'warning' ? 'bg-amber-50 border-amber-100' : 'bg-emerald-50 border-emerald-100'}`}>
                  <p className="text-xs font-black text-slate-800">{item.label}</p>
                  <p className="text-[10px] text-slate-500 mt-1">{item.info}</p>
                </div>
              ))}
           </div>
           <div className="mt-auto pt-6 border-t border-slate-50">
              <button className="w-full py-3 bg-slate-900 text-white rounded-2xl text-xs font-bold flex items-center justify-center gap-2">
                <Printer size={14}/> 导出 PDF 看板
              </button>
           </div>
        </div>
      </div>
    </div>
  );

  const renderPPTPreview = () => (
    <div className="h-full flex flex-col gap-6 animate-in zoom-in-95 duration-500">
      <div className="flex items-center justify-between bg-white px-8 py-4 rounded-[28px] border border-slate-200 shadow-sm">
        <div className="flex items-center gap-4">
          <button onClick={() => setView('bi-preview')} className="p-2.5 bg-slate-50 text-slate-500 rounded-xl hover:bg-slate-100"><ArrowLeft size={20}/></button>
          <div>
            <h3 className="text-sm font-bold text-slate-800">PPT 实时编辑器</h3>
            <p className="text-[10px] text-slate-400 font-bold tracking-widest uppercase">AI Presentation Editor</p>
          </div>
        </div>
        <div className="flex gap-2">
          <button className="flex items-center gap-2 px-5 py-2.5 bg-white border border-slate-200 text-slate-600 rounded-xl text-xs font-bold hover:bg-slate-50">
            <Save size={14}/> 保存
          </button>
          <button className="flex items-center gap-2 px-6 py-2.5 bg-indigo-600 text-white rounded-xl text-xs font-bold hover:bg-indigo-700 shadow-lg shadow-indigo-100">
            <Download size={14}/> 导出 PPTX
          </button>
        </div>
      </div>

      <div className="flex-1 flex gap-6 overflow-hidden">
        {/* Slides List */}
        <div className="w-64 bg-slate-100/50 rounded-[32px] p-4 flex flex-col gap-4 overflow-y-auto scrollbar-hide shrink-0">
           {slides.map((s, i) => (
             <div key={s.id} onClick={() => setActiveSlideIdx(i)} className={`aspect-[16/9] rounded-2xl border-2 transition-all cursor-pointer overflow-hidden relative ${activeSlideIdx === i ? 'border-blue-500 ring-4 ring-blue-500/10' : 'border-slate-200 hover:border-slate-300'}`}>
                <div className="bg-white w-full h-full p-4">
                   <div className="h-1 w-1/2 bg-slate-200 rounded-full mb-2"/>
                   <div className="h-1 w-full bg-slate-100 rounded-full mb-1"/>
                   <div className="h-1 w-2/3 bg-slate-100 rounded-full"/>
                   <div className="absolute inset-0 bg-blue-500/0 hover:bg-blue-500/5 transition-all flex items-center justify-center text-[10px] font-bold text-blue-600 opacity-0 hover:opacity-100">{i+1}</div>
                </div>
             </div>
           ))}
        </div>

        {/* Slide Editor */}
        <div className="flex-1 bg-white rounded-[40px] border border-slate-200 p-20 flex flex-col shadow-inner relative overflow-hidden">
            <div className="absolute top-8 left-10 flex items-center gap-2">
              <span className="text-[10px] font-black text-slate-300 uppercase tracking-widest">Slide {activeSlideIdx + 1} Editor</span>
            </div>
            
            <div className="max-w-3xl mx-auto w-full space-y-12">
               <input 
                 value={slides[activeSlideIdx].title} 
                 onChange={(e) => saveSlideChanges(e.target.value, slides[activeSlideIdx].content)}
                 className="w-full text-5xl font-black text-slate-800 bg-transparent outline-none placeholder:text-slate-100 border-b-2 border-transparent focus:border-blue-100 transition-all pb-4"
               />
               <textarea 
                 value={slides[activeSlideIdx].content}
                 onChange={(e) => saveSlideChanges(slides[activeSlideIdx].title, e.target.value)}
                 className="w-full h-64 text-2xl text-slate-500 bg-transparent outline-none resize-none leading-relaxed focus:text-slate-700 transition-colors"
               />
            </div>

            {/* AI Slide Suggestion */}
            <div className="mt-auto flex items-center gap-4 bg-slate-50 p-6 rounded-[24px] border border-slate-100">
               <div className="w-10 h-10 bg-indigo-50 text-indigo-600 rounded-xl flex items-center justify-center shrink-0"><Sparkles size={18}/></div>
               <p className="text-xs text-slate-500 leading-relaxed font-medium">AI 建议：本页文字较多，建议增加一个“各部门效能对比”的侧向条形图以增强说服力。 <button className="text-blue-600 font-bold hover:underline">一键执行优化</button></p>
            </div>
        </div>
      </div>
    </div>
  );

  return (
    <div className="h-full">
      {isGenerating ? (
        <div className="h-full flex flex-col items-center justify-center animate-pulse">
           <div className="w-16 h-16 bg-blue-600 rounded-2xl flex items-center justify-center text-white mb-6 animate-bounce"><Sparkles size={32}/></div>
           <p className="text-sm font-bold text-slate-800">正在调用震慑 AI 算力中心...</p>
        </div>
      ) : (
        <>
          {view === 'input' && renderInputView()}
          {view === 'bi-preview' && renderBIPreview()}
          {view === 'ppt-preview' && renderPPTPreview()}
        </>
      )}
    </div>
  );
};
