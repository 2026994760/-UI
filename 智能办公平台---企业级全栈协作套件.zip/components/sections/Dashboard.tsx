
import React, { useState, useEffect } from 'react';
import { 
  FileText, 
  Users, 
  CheckCircle2, 
  TrendingUp,
  ArrowUpRight,
  Mic2,
  PenTool,
  Library,
  Activity
} from 'lucide-react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  AreaChart,
  Area
} from 'recharts';
import { mockSystemStatus } from '../../mockApi.ts';

const initialData = [
  { name: 'Mon', usage: 120, docs: 45 },
  { name: 'Tue', usage: 180, docs: 52 },
  { name: 'Wed', usage: 150, docs: 38 },
  { name: 'Thu', usage: 220, docs: 61 },
  { name: 'Fri', usage: 260, docs: 72 },
  { name: 'Sat', usage: 100, docs: 25 },
  { name: 'Sun', usage: 80, docs: 15 },
];

export const Dashboard: React.FC = () => {
  const [status, setStatus] = useState(mockSystemStatus());
  const [chartData, setChartData] = useState(initialData);

  useEffect(() => {
    const timer = setInterval(() => {
      setStatus(mockSystemStatus());
    }, 3000);
    return () => clearInterval(timer);
  }, []);

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      {/* 实时状态条 - 甲方最爱看的“高科技”感 */}
      <div className="bg-slate-900 text-white p-4 rounded-2xl flex items-center justify-between shadow-xl border border-white/5">
        <div className="flex items-center gap-6">
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse shadow-[0_0_8px_#10b981]" />
            <span className="text-[10px] font-bold uppercase tracking-widest text-slate-400">系统状态: 运行中</span>
          </div>
          <div className="h-4 w-px bg-slate-800" />
          <div className="flex gap-4 text-[10px] font-bold">
            <span className="text-slate-500 uppercase">CPU: <span className="text-blue-400">{status.cpu_load}</span></span>
            <span className="text-slate-500 uppercase">延迟: <span className="text-emerald-400">{status.api_latency}</span></span>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Activity size={14} className="text-blue-500 animate-bounce" />
          <span className="text-[10px] font-bold uppercase tracking-tighter text-blue-500">ZhenShe Engine v3.5 Active</span>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {[
          { label: '本月撰写公文', value: '1,284', change: '+12.5%', icon: <FileText className="text-blue-600" />, bg: 'bg-blue-50' },
          { label: '活跃用户', value: '428', change: '+4.2%', icon: <Users className="text-indigo-600" />, bg: 'bg-indigo-50' },
          { label: '任务完成率', value: '98.4%', change: '+0.4%', icon: <CheckCircle2 className="text-emerald-600" />, bg: 'bg-emerald-50' },
          { label: 'AI 平均提效', value: '72%', change: '+8.1%', icon: <TrendingUp className="text-amber-600" />, bg: 'bg-amber-50' },
        ].map((stat, i) => (
          <div key={i} className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex flex-col hover:shadow-md transition-shadow">
            <div className="flex justify-between items-start mb-4">
              <div className={`${stat.bg} p-3 rounded-xl`}>{stat.icon}</div>
              <span className={`text-xs font-bold px-2 py-1 rounded-full ${stat.change.startsWith('+') ? 'text-emerald-600 bg-emerald-50' : 'text-rose-600 bg-rose-50'}`}>
                {stat.change}
              </span>
            </div>
            <span className="text-slate-500 text-sm font-medium">{stat.label}</span>
            <span className="text-2xl font-bold text-slate-800 mt-1">{stat.value}</span>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Usage Chart */}
        <div className="lg:col-span-2 bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between mb-6">
            <h3 className="font-bold text-slate-800 flex items-center gap-2">
              平台使用趋势
              <span className="bg-blue-100 text-blue-600 text-[10px] px-1.5 py-0.5 rounded font-bold uppercase">Realtime</span>
            </h3>
          </div>
          <div className="h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={chartData}>
                <defs>
                  <linearGradient id="colorUsage" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#2563eb" stopOpacity={0.1}/>
                    <stop offset="95%" stopColor="#2563eb" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 12}} dy={10} />
                <YAxis hide />
                <Tooltip 
                  contentStyle={{borderRadius: '12px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)'}}
                />
                <Area type="monotone" dataKey="usage" stroke="#2563eb" strokeWidth={3} fillOpacity={1} fill="url(#colorUsage)" />
                <Area type="monotone" dataKey="docs" stroke="#8b5cf6" strokeWidth={2} fillOpacity={0} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Recent Activity */}
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
          <h3 className="font-bold text-slate-800 mb-6">最新动态</h3>
          <div className="space-y-6">
            {[
              { title: '会议纪要已生成', desc: 'Q4 财务预算会议', time: '2分钟前', icon: <Mic2 size={16} />, color: 'text-indigo-600', bg: 'bg-indigo-50' },
              { title: '文档风格校对完成', desc: '公文：行政管理条例', time: '15分钟前', icon: <PenTool size={16} />, color: 'text-blue-600', bg: 'bg-blue-50' },
              { title: '制度问答库更新', desc: '新增 52 条规章制度', time: '1小时前', icon: <Library size={16} />, color: 'text-emerald-600', bg: 'bg-emerald-50' },
              { title: '安全审计完成', desc: '全量流水已存证至核心', time: '刚刚', icon: <CheckCircle2 size={16} />, color: 'text-slate-600', bg: 'bg-slate-50' },
            ].map((activity, i) => (
              <div key={i} className="flex gap-4 group cursor-pointer">
                <div className={`${activity.bg} ${activity.color} p-2 rounded-lg h-fit group-hover:scale-110 transition-transform`}>
                  {activity.icon}
                </div>
                <div className="flex-1 border-b border-slate-100 pb-4">
                  <div className="flex justify-between items-start">
                    <h4 className="text-sm font-semibold text-slate-800">{activity.title}</h4>
                    <span className="text-[10px] text-slate-400 font-medium">{activity.time}</span>
                  </div>
                  <p className="text-xs text-slate-500 mt-1">{activity.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
