
import React, { useState } from 'react';
import { 
  FileText, Wand2, Type, Layout, Save, Download, X, 
  ClipboardCheck, FileSearch, History, Clock, Trash2, 
  ChevronLeft, Sparkles, Send, CheckCircle2
} from 'lucide-react';

interface WritingTemplate {
  id: string;
  name: string;
  icon: React.ReactNode;
  prompt: string;
  skeleton: string;
  description: string;
}

interface WritingHistory {
  id: string;
  title: string;
  prompt: string;
  content: string;
  templateId: string | null;
  timestamp: string;
}

const TEMPLATES: WritingTemplate[] = [
  { id: 'notice', name: '通知公告', icon: <FileText size={20} />, description: '适用于下发指令、布置工作或告知事项', prompt: '撰写一份关于[事项名称]的正式通知，要求：1. 明确通知范围；2. 详细说明工作要求和时间节点；3. 语气严肃规范。', skeleton: '关于[事项名称]的通知\n\n各部室、下属各单位：\n\n为贯彻落实[相关政策/上级精神]，现就[事项名称]有关事宜通知如下：\n\n一、 [主要目标/背景]\n\n二、 [具体工作要求]\n\n三、 [时间安排及注意事项]\n\n[单位名称]\n2024年[月][日]' },
  { id: 'summary', name: '工作总结', icon: <ClipboardCheck size={20} />, description: '用于阶段性工作回顾、成绩总结与反思', prompt: '撰写2024年[部门/个人]季度工作总结。要求：1. 总结主要成绩；2. 分析存在的问题；3. 提出下一步改进方向。', skeleton: '2024年[部门/单位]工作总结报告\n\n今年以来，在集团公司的正确领导下，我部紧紧围绕[年度核心目标]，积极开展工作，现将主要工作情况总结如下：\n\n一、 主要工作任务完成情况\n\n二、 取得的主要成效及亮点\n\n三、 存在的问题及原因分析\n\n四、 下一步工作建议及计划' },
  { id: 'report', name: '请示报告', icon: <FileSearch size={20} />, description: '向上级请求批准事项或汇报重大情况', prompt: '就[某项目/采购/活动]事项向集团领导提交请示。要求：1. 说明理由充分；2. 方案具体可行；3. 明确请示事项。', skeleton: '关于[申请事项]的请示\n\n集团领导：\n\n因[申请理由/背景原因]，现拟开展[项目名称/采购计划]，具体方案如下：\n\n一、 开展的必要性及紧迫性\n\n二、 具体实施方案及预算测算\n\n三、 预期目标及效益分析\n\n妥否，请批示。' }
];

export const AIWriting: React.FC = () => {
  const [prompt, setPrompt] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [content, setContent] = useState('请在上方输入公文创作指令或选择模版，AI 将为您生成标准内容...');
  const [showTemplates, setShowTemplates] = useState(false);
  const [selectedTemplate, setSelectedTemplate] = useState<WritingTemplate | null>(null);
  
  const [histories, setHistories] = useState<WritingHistory[]>([
    { id: 'h-1', title: '冬季节能减排通知', prompt: '撰写冬季节能减排通知...', content: '关于加强2024年度冬季节能减排工作的通知...', templateId: 'notice', timestamp: '10:30' }
  ]);

  const handleGenerate = () => {
    if (!prompt) return;
    setIsGenerating(true);
    setTimeout(() => {
      const gen = `关于[事项]的最新生成的公文内容...\n\n基于指令：${prompt}\n\n[正文内容已通过核校]`;
      setContent(gen);
      setIsGenerating(false);
      setHistories([{ id: Date.now().toString(), title: prompt.slice(0, 12) + '...', prompt, content: gen, templateId: selectedTemplate?.id || null, timestamp: '刚刚' }, ...histories]);
    }, 1200);
  };

  const loadHistory = (h: WritingHistory) => {
    setPrompt(h.prompt);
    setContent(h.content);
    setSelectedTemplate(TEMPLATES.find(t => t.id === h.templateId) || null);
  };

  return (
    <div className="h-full flex flex-col gap-6 overflow-hidden">
      <div className="bg-white p-8 rounded-[32px] border border-slate-200 shadow-sm space-y-4 shrink-0">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
             <div className="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center text-white shadow-lg"><Sparkles size={20}/></div>
             <div>
               <h3 className="text-sm font-bold text-slate-800">公文创作指令区</h3>
               <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Prompt Interface</p>
             </div>
          </div>
          <div className="flex gap-2">
            <button onClick={() => setShowTemplates(true)} className="px-4 py-2 bg-slate-50 border border-slate-100 text-slate-600 rounded-xl text-xs font-bold hover:bg-slate-100 transition-all">
              {selectedTemplate ? `已选模版: ${selectedTemplate.name}` : '从模版库选择'}
            </button>
            {selectedTemplate && <button onClick={() => setSelectedTemplate(null)} className="p-2 text-slate-300 hover:text-rose-500"><X size={16}/></button>}
          </div>
        </div>
        
        <div className="relative group">
          <textarea 
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder="在此输入您的详细公文写作要求，例如：『请帮我起草一份关于组织全体员工参加防诈骗安全知识讲座的通知，要求强调参与度，并附上时间、地点占位符。』"
            className="w-full h-32 p-6 bg-slate-50 border border-slate-100 rounded-[24px] text-lg focus:ring-8 focus:ring-blue-500/5 outline-none resize-none transition-all placeholder:text-slate-300 leading-relaxed font-medium"
          />
          <button 
            onClick={handleGenerate}
            disabled={!prompt || isGenerating}
            className="absolute bottom-4 right-4 px-8 py-3 bg-blue-600 text-white rounded-2xl font-bold text-sm shadow-xl shadow-blue-200 hover:bg-blue-700 active:scale-95 disabled:opacity-50 transition-all flex items-center gap-2"
          >
            {isGenerating ? <div className="animate-spin w-4 h-4 border-2 border-white/30 border-t-white rounded-full"/> : <Send size={18}/>}
            {isGenerating ? 'AI 解析中...' : '立即创作'}
          </button>
        </div>
      </div>

      <div className="flex-1 flex gap-6 overflow-hidden">
        <div className="w-64 bg-white rounded-[32px] border border-slate-200 shadow-sm flex flex-col overflow-hidden shrink-0">
          <div className="p-5 border-b border-slate-50 bg-slate-50/50 flex items-center justify-between">
            <h3 className="text-xs font-bold text-slate-800 flex items-center gap-2"><History size={14} className="text-slate-400" /> 创作历史</h3>
          </div>
          <div className="flex-1 overflow-y-auto p-3 space-y-2 scrollbar-hide">
            {histories.map(h => (
              <div key={h.id} onClick={() => loadHistory(h)} className="p-3 rounded-2xl border border-transparent hover:border-blue-100 hover:bg-blue-50/40 cursor-pointer transition-all">
                <p className="text-[11px] font-bold text-slate-700 truncate">{h.title}</p>
                <span className="text-[9px] text-slate-400 flex items-center gap-1 mt-1"><Clock size={10}/> {h.timestamp}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="flex-1 bg-white rounded-[40px] border border-slate-200 shadow-sm flex flex-col overflow-hidden relative">
          <div className="h-14 border-b border-slate-50 px-8 flex items-center justify-between bg-slate-50/20">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">智能办公云编辑器</span>
            <div className="flex gap-2">
              <button className="flex items-center gap-2 px-6 py-1.5 bg-slate-900 text-white rounded-xl text-xs font-bold shadow-xl hover:bg-slate-800">
                <Download size={14} /> 导出
              </button>
            </div>
          </div>
          <div className="flex-1 p-16 overflow-y-auto font-serif text-lg leading-[1.8] text-slate-700 bg-white">
            <div className="max-w-2xl mx-auto whitespace-pre-wrap">{content}</div>
          </div>
        </div>
      </div>

      {showTemplates && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm z-50 flex items-center justify-center p-8" onClick={() => setShowTemplates(false)}>
          <div className="bg-white rounded-[32px] w-full max-w-4xl p-8 shadow-2xl animate-in zoom-in-95 duration-300" onClick={e => e.stopPropagation()}>
             <h2 className="text-xl font-bold mb-6 text-slate-800">选择写作模版</h2>
             <div className="grid grid-cols-2 gap-4">
               {TEMPLATES.map(t => (
                 <button key={t.id} onClick={() => { setSelectedTemplate(t); setPrompt(t.prompt); setContent(t.skeleton); setShowTemplates(false); }} className="flex gap-4 p-5 rounded-2xl border border-slate-100 hover:border-blue-400 hover:bg-blue-50 text-left transition-all">
                    <div className="w-12 h-12 bg-blue-50 text-blue-600 rounded-xl flex items-center justify-center">{t.icon}</div>
                    <div><h4 className="text-sm font-bold text-slate-800">{t.name}</h4><p className="text-[11px] text-slate-400 mt-1">{t.description}</p></div>
                 </button>
               ))}
             </div>
          </div>
        </div>
      )}
    </div>
  );
};
