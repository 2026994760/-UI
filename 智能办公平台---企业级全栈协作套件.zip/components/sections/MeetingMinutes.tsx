
import React, { useState, useMemo } from 'react';
import { 
  Play, Pause, Download, Search, Plus, Users, X, 
  CheckCircle2, ChevronLeft, Sparkles, 
  Edit3, ListTodo, Gavel, Volume2, 
  BrainCircuit, Clock3, FileDown, FileType,
  Mic, FileAudio, Loader2, ArrowRight, ChevronRight,
  UploadCloud, FileType2, Building2, User, UserPlus, Globe
} from 'lucide-react';

interface Participant {
  id: string;
  name: string;
  dept: string;
  isExternal?: boolean;
}

interface ActionItem {
  id: string;
  owner: string;
  task: string;
  deadline: string;
}

interface DecisionItem {
  id: string;
  topic: string;
  content: string;
}

interface MeetingRecord {
  id: string;
  title: string;
  time: string;
  duration: string;
  status: '已完成' | '处理中';
  participants: Participant[];
  decisions: DecisionItem[];
  actionItems: ActionItem[];
  summary: string;
  sentiment: 'positive' | 'neutral' | 'urgent';
  tags: string[];
  matchScore?: number;
}

const SYSTEM_USERS = [
  { id: 'u1', name: '张主任', dept: '行政部' },
  { id: 'u2', name: '李会计', dept: '财务部' },
  { id: 'u3', name: '王总监', dept: '数字化部' },
  { id: 'u4', name: '赵律师', dept: '法务部' },
  { id: 'u5', name: '陈经理', dept: '市场部' },
  { id: 'u6', name: '孙工', dept: '技术部' },
  { id: 'u7', name: '周总', dept: '总经办' },
];

export const MeetingMinutes: React.FC = () => {
  const [view, setView] = useState<'list' | 'result'>('list');
  const [searchQuery, setSearchQuery] = useState('');
  const [isPlaying, setIsPlaying] = useState(false);
  
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [createStep, setCreateStep] = useState<'config' | 'processing' | 'success'>('config');
  const [uploadProgress, setUploadProgress] = useState(0);
  const [processStatus, setProcessStatus] = useState('正在提取音频特征...');

  const [tempTopic, setTempTopic] = useState('');
  const [tempParticipants, setTempParticipants] = useState<Participant[]>([]);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  
  const [participantMode, setParticipantMode] = useState<'internal' | 'external'>('internal');
  const [participantInput, setParticipantInput] = useState('');
  const [showUserSuggestions, setShowUserSuggestions] = useState(false);

  // 外部人员录入状态
  const [extName, setExtName] = useState('');
  const [extOrg, setExtOrg] = useState('');

  const [meetings, setMeetings] = useState<MeetingRecord[]>([
    { 
      id: 'm1',
      title: '集团2024Q3季度经营分析会', 
      time: '2024-10-24 14:00', 
      duration: '124 min', 
      status: '已完成', 
      sentiment: 'neutral',
      tags: ['经营分析', '财务预算', '季度决策'],
      participants: [
        { id: 'p1', name: '张主任', dept: '行政部' },
        { id: 'p2', name: '李会计', dept: '财务部' },
        { id: 'p3', name: '王总监', dept: '数字化部' }
      ],
      decisions: [{ id: 'd1', topic: 'Q4预算', content: '会议通过 Q4 预算草案，行政部需缩减 5% 的非必要开支。' }],
      actionItems: [{ id: 'a1', owner: '财务部', task: '完善预算明细并提交审核', deadline: '2024-11-25' }],
      summary: '本次会议主要针对三季度经营情况进行了剖析，各部门负责人汇报了核心指标完成情况。',
    },
    { 
      id: 'm2',
      title: '关于冬季办公节能专题研讨', 
      time: '2024-10-22 09:30', 
      duration: '45 min', 
      status: '已完成',
      sentiment: 'positive',
      tags: ['节能减排', '行政规范'],
      participants: [{ id: 'p1', name: '张主任', dept: '行政部' }],
      decisions: [{ id: 'd2', topic: '空调管控', content: '室内温度统一设定为22度。' }],
      actionItems: [],
      summary: '研讨确定了冬季空调开放时间和温度标准，旨在提升员工舒适度的同时降低能耗。',
    }
  ]);

  const [activeMeeting, setActiveMeeting] = useState<MeetingRecord | null>(null);

  const suggestions = useMemo(() => {
    if (!participantInput) return SYSTEM_USERS.slice(0, 3).filter(u => !tempParticipants.find(p => p.id === u.id));
    return SYSTEM_USERS.filter(u => 
      u.name.includes(participantInput) || u.dept.includes(participantInput)
    ).filter(u => !tempParticipants.find(p => p.id === u.id));
  }, [participantInput, tempParticipants]);

  const addParticipant = (user: Participant) => {
    setTempParticipants([...tempParticipants, user]);
    setParticipantInput('');
    setShowUserSuggestions(false);
  };

  const addExternalParticipant = () => {
    if (!extName || !extOrg) return;
    const newExt: Participant = {
      id: `ext-${Date.now()}`,
      name: extName,
      dept: extOrg,
      isExternal: true
    };
    setTempParticipants([...tempParticipants, newExt]);
    setExtName('');
    setExtOrg('');
  };

  const removeParticipant = (id: string) => {
    setTempParticipants(tempParticipants.filter(p => p.id !== id));
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setSelectedFile(e.target.files[0]);
    }
  };

  const handleStartAnalysis = () => {
    setCreateStep('processing');
    let prog = 0;
    const statuses = [
      '正在提取音频特征...',
      '正在识别发言人声纹...',
      '语义对齐与内容转写...',
      '核心决策点智能挖掘...',
      '行动项自动化分类...',
      '正在生成纪要文档...'
    ];
    
    const interval = setInterval(() => {
      prog += 2;
      setUploadProgress(prog);
      const statusIdx = Math.min(Math.floor(prog / 17), statuses.length - 1);
      setProcessStatus(statuses[statusIdx]);
      if (prog >= 100) {
        clearInterval(interval);
        setTimeout(() => setCreateStep('success'), 500);
      }
    }, 80);
  };

  const handleFinishCreate = () => {
    const newMeeting: MeetingRecord = {
      id: `m-${Date.now()}`,
      title: tempTopic || '智能生成的会议纪要',
      time: new Date().toLocaleString(),
      duration: '32 min',
      status: '已完成',
      participants: tempParticipants,
      sentiment: 'positive',
      tags: ['AI分析', '实时任务'],
      decisions: [{ id: 'd-new', topic: '智能决议', content: 'AI 根据音频内容自动识别出的核心决策事项...' }],
      actionItems: [{ id: 'a-new', owner: tempParticipants[0]?.name || '负责人', task: '待办任务跟进事项', deadline: '2024-12-01' }],
      summary: '这是一份由震慑 AI 系统基于您上传的音频和配置的参会人自动生成的深度会议纪要。'
    };
    setMeetings([newMeeting, ...meetings]);
    setActiveMeeting(newMeeting);
    setView('result');
    setShowCreateModal(false);
    setCreateStep('config');
    setUploadProgress(0);
    setTempTopic('');
    setTempParticipants([]);
    setSelectedFile(null);
  };

  const renderCreateModal = () => (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-md z-[100] flex items-center justify-center p-6 animate-in fade-in duration-300">
       <div className="bg-white w-full max-w-4xl rounded-[48px] shadow-2xl overflow-hidden relative flex flex-col max-h-[90vh]">
          {createStep !== 'processing' && (
            <button onClick={() => setShowCreateModal(false)} className="absolute top-8 right-8 p-2 text-slate-300 hover:text-slate-600 transition-colors z-10">
              <X size={24}/>
            </button>
          )}

          <div className="flex-1 overflow-y-auto p-12 scrollbar-hide">
            {createStep === 'config' && (
              <div className="space-y-10 animate-in slide-in-from-bottom-4">
                 <div className="text-center">
                    <div className="w-16 h-16 bg-blue-600 text-white rounded-[24px] flex items-center justify-center mx-auto mb-6 shadow-xl shadow-blue-200">
                      <Sparkles size={32}/>
                    </div>
                    <h2 className="text-3xl font-black text-slate-800">发起智能会议纪要</h2>
                    <p className="text-sm text-slate-400 mt-2 font-medium">震慑 AI 将基于音频内容为您提取决议与行动项</p>
                 </div>

                 <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
                    <div className="space-y-8">
                      <div className="space-y-3">
                         <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-2">
                           <Edit3 size={12}/> 会议主题 (可选)
                         </label>
                         <input 
                           type="text"
                           value={tempTopic}
                           onChange={(e) => setTempTopic(e.target.value)}
                           placeholder="输入本次会议的核心标题..."
                           className="w-full px-6 py-4 bg-slate-50 border border-slate-100 rounded-2xl text-sm focus:ring-4 focus:ring-blue-500/10 outline-none transition-all font-bold text-slate-700"
                         />
                      </div>

                      <div className="space-y-3">
                         <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-2">
                           <Volume2 size={12}/> 会议音频录音 (必传)
                         </label>
                         <div className={`relative group border-2 border-dashed rounded-3xl p-8 flex flex-col items-center justify-center transition-all ${selectedFile ? 'border-blue-400 bg-blue-50/30' : 'border-slate-200 hover:border-blue-400 bg-slate-50'}`}>
                            <input type="file" accept="audio/*" onChange={handleFileChange} className="absolute inset-0 opacity-0 cursor-pointer z-10" />
                            {selectedFile ? (
                              <div className="text-center animate-in zoom-in-95">
                                 <div className="w-14 h-14 bg-blue-600 text-white rounded-full flex items-center justify-center mx-auto mb-4">
                                   <FileType2 size={24}/>
                                 </div>
                                 <p className="text-sm font-bold text-slate-800 truncate max-w-[200px]">{selectedFile.name}</p>
                                 <p className="text-[10px] text-blue-600 font-bold mt-1 uppercase tracking-widest">已就绪</p>
                              </div>
                            ) : (
                              <>
                                <UploadCloud size={32} className="text-slate-300 group-hover:text-blue-500 transition-colors mb-3" />
                                <p className="text-xs font-bold text-slate-400">点击或拖拽音频文件到此处</p>
                                <p className="text-[9px] text-slate-300 mt-1 uppercase font-bold">WAV, MP3, M4A up to 500MB</p>
                              </>
                            )}
                         </div>
                      </div>
                    </div>

                    <div className="space-y-8">
                       <div className="space-y-4 relative">
                          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest flex justify-between">
                            <span className="flex items-center gap-2"><Users size={12}/> 参会人员配置 (必填)</span>
                            <span className="text-blue-600">{tempParticipants.length} 位已选</span>
                          </label>
                          
                          {/* 录入模式切换 */}
                          <div className="flex bg-slate-100 p-1 rounded-xl">
                             <button 
                               onClick={() => setParticipantMode('internal')}
                               className={`flex-1 py-2 text-[10px] font-black uppercase rounded-lg transition-all ${participantMode === 'internal' ? 'bg-white text-blue-600 shadow-sm' : 'text-slate-400 hover:text-slate-600'}`}
                             >
                               内部通讯录
                             </button>
                             <button 
                               onClick={() => setParticipantMode('external')}
                               className={`flex-1 py-2 text-[10px] font-black uppercase rounded-lg transition-all ${participantMode === 'external' ? 'bg-white text-amber-600 shadow-sm' : 'text-slate-400 hover:text-slate-600'}`}
                             >
                               外部访客录入
                             </button>
                          </div>

                          {participantMode === 'internal' ? (
                             <div className="relative animate-in fade-in slide-in-from-left-2 duration-300">
                                <input 
                                  type="text"
                                  value={participantInput}
                                  onFocus={() => setShowUserSuggestions(true)}
                                  onChange={(e) => setParticipantInput(e.target.value)}
                                  placeholder="搜索内部员工姓名或部门..."
                                  className="w-full px-12 py-4 bg-slate-50 border border-slate-100 rounded-2xl text-sm focus:ring-4 focus:ring-blue-500/10 outline-none transition-all font-bold text-slate-700"
                                />
                                <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300" size={18} />
                                {showUserSuggestions && (
                                  <div className="absolute top-full left-0 right-0 mt-2 bg-white border border-slate-100 rounded-2xl shadow-2xl z-50 overflow-hidden max-h-48 overflow-y-auto scrollbar-hide animate-in slide-in-from-top-2">
                                     {suggestions.map(user => (
                                       <button key={user.id} onClick={() => addParticipant(user)} className="w-full px-6 py-3 text-left hover:bg-blue-50 flex items-center gap-3 border-b border-slate-50 last:border-none transition-colors">
                                         <div className="w-8 h-8 rounded-lg bg-blue-100 text-blue-600 flex items-center justify-center text-xs font-bold">{user.name[0]}</div>
                                         <div>
                                            <p className="text-xs font-bold text-slate-800">{user.name}</p>
                                            <p className="text-[9px] text-slate-400 font-bold uppercase">{user.dept}</p>
                                         </div>
                                       </button>
                                     ))}
                                  </div>
                                )}
                             </div>
                          ) : (
                             <div className="space-y-3 animate-in fade-in slide-in-from-right-2 duration-300">
                                <div className="grid grid-cols-2 gap-3">
                                   <input 
                                     value={extName}
                                     onChange={(e) => setExtName(e.target.value)}
                                     placeholder="访客姓名"
                                     className="px-5 py-3.5 bg-slate-50 border border-slate-100 rounded-2xl text-sm font-bold focus:ring-4 focus:ring-amber-500/10 outline-none"
                                   />
                                   <input 
                                     value={extOrg}
                                     onChange={(e) => setExtOrg(e.target.value)}
                                     placeholder="所属单位/机构"
                                     className="px-5 py-3.5 bg-slate-50 border border-slate-100 rounded-2xl text-sm font-bold focus:ring-4 focus:ring-amber-500/10 outline-none"
                                   />
                                </div>
                                <button 
                                  onClick={addExternalParticipant}
                                  disabled={!extName || !extOrg}
                                  className="w-full py-3 bg-amber-50 text-amber-600 rounded-2xl text-[10px] font-black uppercase flex items-center justify-center gap-2 hover:bg-amber-100 transition-all disabled:opacity-30 shadow-sm"
                                >
                                  <UserPlus size={14}/> 确认添加外部人员
                                </button>
                             </div>
                          )}

                          <div className="flex flex-wrap gap-2 min-h-[120px] p-4 bg-slate-50/50 rounded-3xl border border-slate-100 border-dashed overflow-y-auto max-h-40 scrollbar-hide">
                             {tempParticipants.map(p => (
                               <div key={p.id} className={`px-4 py-2 bg-white border rounded-2xl flex items-center gap-2 shadow-sm animate-in zoom-in-90 transition-all ${p.isExternal ? 'border-amber-100 hover:border-amber-400' : 'border-slate-100 hover:border-blue-400'}`}>
                                  <div className={`w-6 h-6 rounded-lg flex items-center justify-center text-[9px] font-black ${p.isExternal ? 'bg-amber-50 text-amber-600' : 'bg-blue-50 text-blue-600'}`}>
                                    {p.isExternal ? <Globe size={12}/> : p.name[0]}
                                  </div>
                                  <div className="flex flex-col">
                                     <span className="text-xs font-black text-slate-700 leading-none">{p.name}</span>
                                     <span className="text-[8px] text-slate-400 font-bold uppercase mt-0.5">{p.dept}</span>
                                  </div>
                                  <button onClick={() => removeParticipant(p.id)} className="ml-1 text-slate-300 hover:text-rose-500 transition-colors"><X size={14}/></button>
                               </div>
                             ))}
                          </div>
                       </div>
                    </div>
                 </div>

                 <div className="pt-6 border-t border-slate-50">
                    <button 
                      disabled={!selectedFile || tempParticipants.length === 0}
                      onClick={handleStartAnalysis}
                      className="w-full py-5 bg-blue-600 text-white rounded-[24px] font-black text-sm shadow-2xl shadow-blue-100 hover:bg-blue-700 transition-all flex items-center justify-center gap-3 disabled:opacity-20 hover:scale-[1.01] active:scale-[0.99]"
                    >
                      开始震慑 AI 智能深度解析 <ChevronRight size={20}/>
                    </button>
                 </div>
              </div>
            )}

            {createStep === 'processing' && (
              <div className="py-20 space-y-12 text-center animate-in fade-in zoom-in-95">
                 <div className="relative mb-8 inline-block mx-auto">
                    <div className="w-32 h-32 bg-blue-50 rounded-full flex items-center justify-center animate-pulse">
                       <BrainCircuit size={64} className="text-blue-600" strokeWidth={1}/>
                    </div>
                    <div className="absolute -top-2 -right-2 w-10 h-10 bg-white shadow-xl rounded-2xl flex items-center justify-center text-blue-600 animate-bounce">
                       <Sparkles size={20}/>
                    </div>
                 </div>
                 <div className="space-y-4">
                    <h3 className="text-3xl font-black text-slate-800 tracking-tight">{processStatus}</h3>
                    <p className="text-sm text-slate-400 font-medium">震慑 AI 正在为您从海量音频流中提取结构化知识...</p>
                 </div>
                 <div className="max-w-md mx-auto space-y-4">
                    <div className="h-3 w-full bg-slate-100 rounded-full overflow-hidden shadow-inner p-0.5">
                       <div className="h-full bg-gradient-to-r from-blue-500 to-indigo-600 rounded-full transition-all duration-300 shadow-lg" style={{ width: `${uploadProgress}%` }} />
                    </div>
                    <div className="flex justify-between items-center px-1 text-[10px] font-black uppercase tracking-widest">
                      <span className="text-blue-600">Progress: {uploadProgress}%</span>
                      <span className="text-slate-300">Engine: 智能办公助手</span>
                    </div>
                 </div>
              </div>
            )}

            {createStep === 'success' && (
              <div className="py-20 flex flex-col items-center text-center animate-in zoom-in-95">
                 <div className="w-24 h-24 bg-emerald-50 text-emerald-500 rounded-[32px] flex items-center justify-center mb-10 shadow-xl shadow-emerald-100 animate-bounce">
                    <CheckCircle2 size={48}/>
                 </div>
                 <h2 className="text-4xl font-black text-slate-800">解析全量完成</h2>
                 <p className="text-slate-400 mt-4 max-w-sm font-medium">会议决议、待办项及语义摘要已同步至云端。</p>
                 <button onClick={handleFinishCreate} className="mt-12 px-16 py-5 bg-slate-900 text-white rounded-[24px] font-black text-sm shadow-2xl hover:bg-slate-800 transition-all flex items-center gap-3 group">
                    立即查看成果 <ArrowRight size={20} className="group-hover:translate-x-1 transition-transform" />
                 </button>
              </div>
            )}
          </div>
       </div>
    </div>
  );

  const renderListView = () => (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div className="bg-white p-10 rounded-[48px] border border-slate-200 shadow-sm overflow-hidden relative group">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h3 className="text-xl font-black text-slate-800 flex items-center gap-3">
              <Sparkles size={24} className="text-blue-600"/> 语义知识图谱中心
            </h3>
            <p className="text-[10px] text-slate-400 font-black uppercase tracking-[0.2em] mt-1">Enterprise Meeting Insight</p>
          </div>
        </div>
        <div className="flex flex-wrap gap-3">
          {['经营季度分析', 'Q4 财务预算', '节能管理专项', '数字化转型', '法务合规', '绩效考核'].map((tag, i) => (
            <button key={i} className={`px-6 py-3 rounded-2xl text-[11px] font-black bg-blue-50 text-blue-600 border border-blue-100/50 hover:bg-blue-100 hover:scale-105 transition-all`}>
              #{tag}
            </button>
          ))}
        </div>
      </div>

      <div className="flex items-center justify-between">
        <button onClick={() => { setCreateStep('config'); setShowCreateModal(true); }} className="flex items-center gap-3 px-10 py-5 bg-blue-600 text-white rounded-[28px] text-sm font-black shadow-2xl shadow-blue-100 hover:bg-blue-700 transition-all hover:scale-105 active:scale-95 group">
          <Plus size={20} /> 发起 AI 会议纪要
        </button>
        <div className="flex gap-4">
          <div className="relative">
            <Search className="absolute left-6 top-1/2 -translate-y-1/2 text-slate-300" size={18} />
            <input type="text" value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} placeholder="搜索企业级知识积淀..." className="pl-16 pr-8 py-5 bg-white border border-slate-200 rounded-[28px] text-sm focus:ring-8 focus:ring-blue-500/5 outline-none w-96 transition-all shadow-sm font-bold text-slate-600" />
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {meetings.map((meeting) => (
          <div key={meeting.id} onClick={() => { setActiveMeeting(meeting); setView('result'); }} className={`group bg-white p-10 rounded-[48px] border-2 border-slate-100 hover:border-blue-500 transition-all cursor-pointer relative overflow-hidden hover:shadow-2xl hover:shadow-blue-50/50`}>
            <div className="flex gap-6 mb-10">
               <div className="w-20 h-20 rounded-[32px] bg-blue-50 text-blue-600 flex items-center justify-center group-hover:bg-blue-600 group-hover:text-white transition-all shadow-sm">
                  <Volume2 size={36} />
               </div>
               <div className="flex-1 min-w-0">
                  <h4 className="text-xl font-black text-slate-800 group-hover:text-blue-600 transition-colors leading-tight truncate">{meeting.title}</h4>
                  <div className="flex items-center gap-4 mt-3 text-[10px] text-slate-400 font-black uppercase tracking-[0.15em]">
                     <span className="flex items-center gap-1.5"><Clock3 size={14}/> {meeting.time}</span>
                     <span className="flex items-center gap-1.5"><User size={14}/> {meeting.participants.length} 人</span>
                  </div>
               </div>
            </div>
            <div className="flex flex-wrap gap-2">
               {meeting.tags.map(tag => (
                 <span key={tag} className="px-4 py-2 bg-slate-50 text-slate-500 rounded-xl text-[9px] font-black uppercase tracking-widest">{tag}</span>
               ))}
            </div>
          </div>
        ))}
      </div>
      {showCreateModal && renderCreateModal()}
    </div>
  );

  const renderResult = () => {
    if (!activeMeeting) return null;
    return (
      <div className="max-w-6xl mx-auto flex flex-col gap-8 animate-in slide-in-from-bottom-8 duration-700 h-full pb-20">
        <div className="bg-slate-900 p-6 rounded-[32px] text-white flex items-center justify-between shadow-2xl shrink-0">
          <div className="flex items-center gap-6">
            <button onClick={() => setView('list')} className="p-3 bg-white/10 hover:bg-white/20 text-white rounded-2xl transition-all shadow-inner"><ChevronLeft size={24}/></button>
            <div className="h-10 w-px bg-slate-800"/>
            <button onClick={() => setIsPlaying(!isPlaying)} className="w-12 h-12 rounded-2xl bg-blue-600 flex items-center justify-center hover:bg-blue-500 transition-all shadow-xl shadow-blue-500/20 active:scale-95">
              {isPlaying ? <Pause size={20} fill="white" /> : <Play size={20} fill="white" className="ml-1" />}
            </button>
            <div className="flex flex-col">
              <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">语义同步回放</span>
              <span className="text-[9px] font-bold text-blue-400">正在播放：声纹角色 P1 - 张主任</span>
            </div>
          </div>
          <div className="flex gap-3">
             <button className="px-8 py-3 bg-white/10 hover:bg-white/20 text-white rounded-2xl text-xs font-black transition-all flex items-center gap-2"><Edit3 size={16}/> 编辑内容</button>
             <button className="px-10 py-3 bg-blue-600 text-white rounded-2xl text-xs font-black shadow-xl hover:bg-blue-500 transition-all flex items-center gap-2"><Download size={16}/> 导出纪要</button>
          </div>
        </div>

        <div className="bg-white rounded-[64px] border border-slate-200 shadow-sm overflow-hidden flex flex-col">
          <div className="p-20 overflow-y-auto space-y-20 scrollbar-hide">
              <div className="space-y-8 text-center md:text-left">
                <h2 className="text-6xl font-black text-slate-800 leading-[1.05] tracking-tight">{activeMeeting.title}</h2>
                <div className="flex flex-wrap items-center gap-6 text-xs text-slate-400 font-black uppercase tracking-widest">
                    <span className="flex items-center gap-2.5 px-6 py-3 bg-slate-50 rounded-full border border-slate-100"><Clock3 size={18} className="text-blue-500"/> {activeMeeting.time}</span>
                    <span className="flex items-center gap-2.5 px-6 py-3 bg-emerald-50 text-emerald-600 rounded-full border border-emerald-100"><Sparkles size={18}/> 智能办公助手 已完成全量深度解析</span>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-20">
                <section className="space-y-8">
                    <h3 className="text-xs font-black text-slate-400 uppercase tracking-[0.4em] flex items-center gap-3">
                      <BrainCircuit size={20} className="text-blue-600"/> 智能语义摘要
                    </h3>
                    <div className="p-12 bg-slate-50 rounded-[48px] border border-slate-100 text-slate-600 italic leading-[1.8] text-xl font-medium shadow-inner">
                      "{activeMeeting.summary}"
                    </div>
                </section>

                <section className="space-y-8">
                    <h3 className="text-xs font-black text-slate-400 uppercase tracking-[0.4em] flex items-center gap-3">
                      <Users size={20} className="text-indigo-600"/> 参会角色画像
                    </h3>
                    <div className="flex flex-wrap gap-4">
                      {activeMeeting.participants.map(p => (
                        <div key={p.id} className={`px-6 py-4 border rounded-[28px] flex items-center gap-4 shadow-sm transition-all hover:scale-105 ${p.isExternal ? 'bg-amber-50/30 border-amber-100' : 'bg-white border-slate-100'}`}>
                            <div className={`w-10 h-10 rounded-2xl flex items-center justify-center text-xs font-black ${p.isExternal ? 'bg-amber-100 text-amber-600' : 'bg-blue-50 text-blue-600'}`}>
                              {p.isExternal ? <Globe size={18}/> : p.name[0]}
                            </div>
                            <div className="flex flex-col">
                              <div className="flex items-center gap-2">
                                <span className="text-sm font-black text-slate-700">{p.name}</span>
                                {p.isExternal && <span className="text-[7px] font-black bg-amber-600 text-white px-1.5 py-0.5 rounded uppercase tracking-tighter">Guest</span>}
                              </div>
                              <span className="text-[10px] text-slate-400 font-black uppercase tracking-widest">{p.dept}</span>
                            </div>
                        </div>
                      ))}
                    </div>
                </section>
              </div>

              <section className="space-y-12 pt-12 border-t border-slate-100">
                  <h3 className="text-xs font-black text-slate-400 uppercase tracking-[0.4em] flex items-center gap-3">
                    <Gavel size={20} className="text-emerald-600"/> 核心决议与行动计划
                  </h3>
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
                      <div className="space-y-6">
                        <p className="text-[10px] font-black text-emerald-600 uppercase tracking-[0.2em] pl-4">关键决议 (DECS)</p>
                        {activeMeeting.decisions.map(d => (
                          <div key={d.id} className="p-10 bg-emerald-50/40 border border-emerald-100/50 rounded-[48px] flex items-start gap-8 group hover:bg-emerald-50 transition-all">
                             <CheckCircle2 size={32} className="text-emerald-500 mt-1 shrink-0" />
                             <p className="text-lg font-bold text-slate-700 leading-relaxed">{d.content}</p>
                          </div>
                        ))}
                      </div>
                      <div className="space-y-6">
                        <p className="text-[10px] font-black text-blue-600 uppercase tracking-[0.2em] pl-4">行动项 (TASKS)</p>
                        {activeMeeting.actionItems.map(a => (
                          <div key={a.id} className="p-10 bg-blue-50/40 border border-blue-100/50 rounded-[48px] flex items-start gap-8 group hover:bg-blue-50 transition-all">
                             <ListTodo size={32} className="text-blue-500 mt-1 shrink-0" />
                             <div className="flex-1">
                                <p className="text-lg font-black text-slate-800 mb-6">{a.task}</p>
                                <div className="flex gap-12">
                                   <div className="flex flex-col"><span className="text-[10px] font-black text-slate-300 uppercase mb-2">执行主体</span><span className="text-sm font-black text-blue-600">{a.owner}</span></div>
                                   <div className="flex flex-col"><span className="text-[10px] font-black text-slate-300 uppercase mb-2">交付期限</span><span className="text-sm font-black text-slate-500">{a.deadline}</span></div>
                                </div>
                             </div>
                          </div>
                        ))}
                      </div>
                  </div>
              </section>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="h-full" onClick={() => setShowUserSuggestions(false)}>
      {view === 'list' && renderListView()}
      {view === 'result' && renderResult()}
    </div>
  );
};
