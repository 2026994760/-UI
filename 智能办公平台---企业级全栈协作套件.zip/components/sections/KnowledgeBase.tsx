
import React, { useState, useMemo } from 'react';
import { 
  Search, 
  Library, 
  FileText, 
  ChevronRight, 
  Sparkles, 
  Upload, 
  Trash2, 
  Plus,
  Share2,
  Building2,
  CheckCircle2,
  Clock,
  Layers,
  Info,
  Settings2,
  MessageSquare,
  FileSearch,
  ArrowLeft,
  ChevronDown,
  ExternalLink,
  Zap,
  Filter,
  MoreHorizontal,
  History,
  X,
  Edit2,
  User
} from 'lucide-react';

interface KnowledgeChunk {
  id: string;
  text: string;
  metadata: {
    page?: number;
    score?: number;
    vectorId: string;
  };
}

interface KnowledgeFile {
  id: string;
  name: string;
  type: string;
  size: string;
  uploadDate: string;
  status: 'indexed' | 'processing' | 'failed';
  chunks: KnowledgeChunk[];
}

interface KBWorkspace {
  id: string;
  name: string;
  description: string;
  fileCount: number;
  sharedWith: string[];
  owner: string;
  lastUpdated: string;
  color: string;
  files: KnowledgeFile[];
}

interface ChatHistory {
  id: string;
  title: string;
  date: string;
}

export const KnowledgeBase: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'qa' | 'management'>('qa');
  const [selectedKBIds, setSelectedKBIds] = useState<string[]>(['kb-1']);
  
  // Management View Navigation
  const [mgmtView, setMgmtView] = useState<'kb-list' | 'doc-list' | 'chunk-view'>('kb-list');
  const [activeKBInMgmt, setActiveKBInMgmt] = useState<KBWorkspace | null>(null);
  const [activeDocInMgmt, setActiveDocInMgmt] = useState<KnowledgeFile | null>(null);

  // Workspace State
  const [workspaces, setWorkspaces] = useState<KBWorkspace[]>([
    { 
      id: 'kb-1', 
      name: '行政管理制度库', 
      description: '包含公司日常行政、考勤及办公规范', 
      fileCount: 12, 
      sharedWith: ['行政部'], 
      owner: '张主任', 
      lastUpdated: '2024-11-20', 
      color: 'bg-blue-500',
      files: [
        { 
          id: 'f1', name: '2024版行政办公管理规范.pdf', type: 'PDF', size: '2.4 MB', uploadDate: '2024-11-10', status: 'indexed',
          chunks: [
            { id: 'c1', text: '第十七条：员工报销市内交通费应在事务发生后的5个工作日内完成系统填报。', metadata: { page: 12, score: 0.98, vectorId: 'vec_a1' } },
            { id: 'c2', text: '第十八条：单笔金额超过200元需附详细说明，并经部门负责人签字确认。', metadata: { page: 12, score: 0.95, vectorId: 'vec_a2' } },
            { id: 'c3', text: '本规范适用于集团总部及直属分公司全体全职员工。', metadata: { page: 1, score: 0.88, vectorId: 'vec_a3' } },
          ]
        },
        { id: 'f2', name: '员工差旅费报销补充规定.docx', type: 'Word', size: '856 KB', uploadDate: '2024-11-12', status: 'indexed', chunks: [] },
      ]
    },
    { 
      id: 'kb-2', 
      name: '财务合规知识库', 
      description: '税务、报销及财务审计相关文档', 
      fileCount: 8, 
      sharedWith: ['财务部'], 
      owner: '李会计', 
      lastUpdated: '2024-11-18', 
      color: 'bg-emerald-500',
      files: []
    },
    { 
      id: 'kb-3', 
      name: '数字化转型专栏', 
      description: '集团数字化转型战略及技术规范', 
      fileCount: 45, 
      sharedWith: ['全员'], 
      owner: '王总监', 
      lastUpdated: '2024-11-22', 
      color: 'bg-indigo-500',
      files: []
    },
    { 
      id: 'kb-4', 
      name: '法律风控手册', 
      description: '合同审核及法律风险识别指引', 
      fileCount: 22, 
      sharedWith: ['法务部'], 
      owner: '赵律师', 
      lastUpdated: '2024-11-15', 
      color: 'bg-rose-500',
      files: []
    },
  ]);

  const [chatHistory] = useState<ChatHistory[]>([
    { id: 'h1', title: '关于报销额度限制的咨询', date: '今天' },
    { id: 'h2', title: '差旅政策详细解读', date: '昨天' },
    { id: 'h3', title: '数字化转型三期目标确认', date: '2024-11-20' },
    { id: 'h4', title: '劳动合同续签流程咨询', date: '2024-11-18' }
  ]);

  const [messages, setMessages] = useState([
    { role: 'assistant', content: '您好！我是您的智能制度助手。我已准备好为您提供跨部门的政策咨询服务。' }
  ]);
  const [input, setInput] = useState('');

  // UI States for Creation and Menu
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [newKBName, setNewKBName] = useState('');
  const [newKBDesc, setNewKBDesc] = useState('');
  
  const [activeMenuKBId, setActiveMenuKBId] = useState<string | null>(null);
  const [showRenameModal, setShowRenameModal] = useState<string | null>(null); // KB Id
  const [renameValue, setRenameValue] = useState('');
  
  const [showCreatorId, setShowCreatorId] = useState<string | null>(null); // KB Id

  const toggleKBSelection = (id: string) => {
    setSelectedKBIds(prev => 
      prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]
    );
  };

  const handleCreateKB = () => {
    if (!newKBName || !newKBDesc) return;
    const newKB: KBWorkspace = {
      id: `kb-${Date.now()}`,
      name: newKBName,
      description: newKBDesc,
      fileCount: 0,
      sharedWith: ['本人'],
      owner: '当前用户',
      lastUpdated: new Date().toISOString().split('T')[0],
      color: 'bg-slate-500',
      files: []
    };
    setWorkspaces([...workspaces, newKB]);
    setNewKBName('');
    setNewKBDesc('');
    setShowCreateModal(false);
  };

  const handleDeleteKB = (id: string) => {
    setWorkspaces(workspaces.filter(kb => kb.id !== id));
    setActiveMenuKBId(null);
  };

  const handleRenameKB = () => {
    if (!renameValue || !showRenameModal) return;
    setWorkspaces(workspaces.map(kb => kb.id === showRenameModal ? { ...kb, name: renameValue } : kb));
    setShowRenameModal(null);
    setRenameValue('');
  };

  const handleSend = () => {
    if (!input || selectedKBIds.length === 0) return;
    const userMsg = { role: 'user', content: input };
    setMessages(prev => [...prev, userMsg]);
    setInput('');
    
    const activeKBNames = workspaces
      .filter(kb => selectedKBIds.includes(kb.id))
      .map(kb => kb.name)
      .join('、');

    setTimeout(() => {
      setMessages(prev => [...prev, { 
        role: 'assistant', 
        content: `已从选定的【${activeKBNames}】中提取相关政策：\n\n根据现有选定制度，跨部门报销审批需满足以下条件：\n1. 涉及${activeKBNames.includes('财务') ? '财务审计' : '行政'}复核流程。\n2. 单笔金额超限需提交数字化审批单。\n\n参考文档：\n- 《行政管理规范》第8章\n- 《合规手册》第32页`
      }]);
    }, 1000);
  };

  // --- Render Functions ---

  const renderKBList = () => (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 animate-in fade-in slide-in-from-bottom-4">
      {workspaces.map(kb => (
        <div 
          key={kb.id}
          className="group bg-white p-6 rounded-3xl border border-slate-200 shadow-sm hover:shadow-xl hover:border-blue-300 transition-all cursor-pointer flex flex-col h-full relative"
          onClick={() => {
            setActiveKBInMgmt(kb);
            setMgmtView('doc-list');
          }}
        >
          <div className="flex items-center justify-between mb-4">
            <div className={`w-12 h-12 rounded-2xl flex items-center justify-center ${kb.color} text-white shadow-lg`}>
              <Library size={24} />
            </div>
            <div className="relative">
              <button 
                onClick={(e) => {
                  e.stopPropagation();
                  setActiveMenuKBId(activeMenuKBId === kb.id ? null : kb.id);
                }}
                className="p-2 text-slate-300 hover:text-slate-600 transition-colors rounded-lg hover:bg-slate-50"
              >
                <MoreHorizontal size={20} />
              </button>
              
              {activeMenuKBId === kb.id && (
                <div className="absolute right-0 top-10 w-40 bg-white border border-slate-100 rounded-2xl shadow-2xl z-20 py-2 animate-in fade-in zoom-in-95 duration-200" onClick={(e) => e.stopPropagation()}>
                  <button 
                    onClick={() => { setShowRenameModal(kb.id); setRenameValue(kb.name); setActiveMenuKBId(null); }}
                    className="w-full px-4 py-2.5 text-left text-xs font-bold text-slate-700 hover:bg-slate-50 flex items-center gap-2"
                  >
                    <Edit2 size={14} className="text-blue-500" /> 重命名
                  </button>
                  <button 
                    onClick={() => { setShowCreatorId(kb.id); setActiveMenuKBId(null); }}
                    className="w-full px-4 py-2.5 text-left text-xs font-bold text-slate-700 hover:bg-slate-50 flex items-center gap-2"
                  >
                    <User size={14} className="text-indigo-500" /> 查看创建人
                  </button>
                  <div className="h-px bg-slate-100 my-1 mx-2" />
                  <button 
                    onClick={() => handleDeleteKB(kb.id)}
                    className="w-full px-4 py-2.5 text-left text-xs font-bold text-rose-600 hover:bg-rose-50 flex items-center gap-2"
                  >
                    <Trash2 size={14} /> 删除
                  </button>
                </div>
              )}
            </div>
          </div>
          <h3 className="text-lg font-bold text-slate-800 mb-2">{kb.name}</h3>
          <p className="text-xs text-slate-500 leading-relaxed flex-1 mb-6">{kb.description}</p>
          <div className="pt-4 border-t border-slate-50 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <FileText size={14} className="text-slate-400" />
              <span className="text-[10px] font-bold text-slate-500">{kb.fileCount} 份文件</span>
            </div>
            <span className="text-[10px] font-bold text-slate-300">更新于 {kb.lastUpdated}</span>
          </div>
        </div>
      ))}
      <div 
        className="border-2 border-dashed border-slate-200 rounded-3xl flex flex-col items-center justify-center p-6 text-slate-400 hover:border-blue-400 hover:text-blue-500 cursor-pointer transition-all group min-h-[220px]"
        onClick={() => setShowCreateModal(true)}
      >
        <div className="w-12 h-12 rounded-full bg-slate-50 flex items-center justify-center mb-3 group-hover:bg-blue-50 transition-all">
          <Plus size={24} />
        </div>
        <span className="text-sm font-bold">创建新知识库</span>
      </div>
    </div>
  );

  const renderDocList = () => (
    <div className="flex flex-col gap-4 animate-in fade-in slide-in-from-right-4">
      <div className="flex items-center gap-3 mb-2">
        <button onClick={() => setMgmtView('kb-list')} className="p-2 hover:bg-slate-100 rounded-xl text-slate-400 hover:text-slate-600 transition-all">
          <ArrowLeft size={20} />
        </button>
        <h2 className="text-lg font-bold text-slate-800 flex items-center gap-2">
          {activeKBInMgmt?.name} 
          <span className="text-xs font-medium text-slate-400">/ 文档列表</span>
        </h2>
      </div>

      <div className="bg-white rounded-[32px] border border-slate-200 overflow-hidden shadow-sm">
        <table className="w-full text-left">
          <thead className="bg-slate-50/50 border-b border-slate-100 text-[10px] font-bold text-slate-400 uppercase tracking-widest">
            <tr>
              <th className="px-8 py-5">文件名</th>
              <th className="px-6 py-5">解析状态</th>
              <th className="px-6 py-5">分块数量</th>
              <th className="px-6 py-5">上传日期</th>
              <th className="px-6 py-5 text-right">操作</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 text-sm">
            {(activeKBInMgmt?.files || []).map(f => (
              <tr key={f.id} className="group hover:bg-slate-50 transition-colors cursor-pointer" onClick={() => {
                setActiveDocInMgmt(f);
                setMgmtView('chunk-view');
              }}>
                <td className="px-8 py-5">
                  <div className="flex items-center gap-4">
                     <div className="w-9 h-9 bg-slate-50 text-slate-400 rounded-lg flex items-center justify-center group-hover:bg-white group-hover:text-blue-500 transition-all border border-transparent group-hover:border-slate-100">
                       <FileText size={18}/>
                     </div>
                     <span className="font-semibold text-slate-700">{f.name}</span>
                  </div>
                </td>
                <td className="px-6 py-5">
                  <span className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[10px] font-bold ${f.status === 'indexed' ? 'bg-emerald-50 text-emerald-600' : 'bg-blue-50 text-blue-600'}`}>
                    {f.status === 'indexed' ? <CheckCircle2 size={12}/> : <Clock size={12} className="animate-spin"/>}
                    {f.status === 'indexed' ? '已收录' : '处理中'}
                  </span>
                </td>
                <td className="px-6 py-5 text-slate-500 font-medium">{f.chunks.length || 0} Chunks</td>
                <td className="px-6 py-5 text-slate-400 text-xs">{f.uploadDate}</td>
                <td className="px-6 py-5 text-right">
                  <div className="flex justify-end gap-2">
                    <button className="p-2 text-slate-300 hover:text-blue-600 transition-all"><ExternalLink size={16}/></button>
                    <button className="p-2 text-slate-300 hover:text-rose-600 transition-all"><Trash2 size={16}/></button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );

  const renderChunkView = () => (
    <div className="flex flex-col gap-6 animate-in fade-in slide-in-from-right-4">
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center gap-3">
          <button onClick={() => setMgmtView('doc-list')} className="p-2 hover:bg-slate-100 rounded-xl text-slate-400 hover:text-slate-600 transition-all">
            <ArrowLeft size={20} />
          </button>
          <div className="flex flex-col">
            <h2 className="text-lg font-bold text-slate-800 flex items-center gap-2">
              {activeDocInMgmt?.name} 
              <span className="text-xs font-medium text-slate-400">/ 知识分块预览</span>
            </h2>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {(activeDocInMgmt?.chunks || []).map((chunk, idx) => (
          <div key={chunk.id} className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm hover:border-blue-400 hover:shadow-md transition-all flex flex-col gap-4 relative overflow-hidden">
            <p className="text-xs text-slate-700 leading-relaxed font-medium bg-slate-50/50 p-3 rounded-xl min-h-[80px]">
              "{chunk.text}"
            </p>
          </div>
        ))}
      </div>
    </div>
  );

  return (
    <div className="h-full flex flex-col gap-4 animate-in fade-in duration-500 relative" onClick={() => setActiveMenuKBId(null)}>
      
      {/* Modals Overlay */}
      {(showCreateModal || showRenameModal || showCreatorId) && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          {showCreateModal && (
            <div className="bg-white rounded-[32px] w-full max-w-lg p-8 shadow-2xl animate-in zoom-in-95 duration-300 flex flex-col gap-6" onClick={(e) => e.stopPropagation()}>
              <div className="flex items-center justify-between">
                <h2 className="text-xl font-bold text-slate-800">创建新知识库</h2>
                <button onClick={() => setShowCreateModal(false)} className="p-2 hover:bg-slate-50 rounded-xl transition-all"><X size={20}/></button>
              </div>
              <div className="space-y-4">
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-400 uppercase tracking-widest">知识库名称</label>
                  <input 
                    type="text" 
                    value={newKBName}
                    onChange={(e) => setNewKBName(e.target.value)}
                    placeholder="输入知识库名称..."
                    className="w-full px-5 py-3.5 bg-slate-50 border border-slate-100 rounded-2xl text-sm focus:ring-4 focus:ring-blue-500/10 outline-none transition-all"
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-400 uppercase tracking-widest">知识库描述</label>
                  <textarea 
                    value={newKBDesc}
                    onChange={(e) => setNewKBDesc(e.target.value)}
                    placeholder="简要描述知识库的用途和范畴..."
                    className="w-full h-32 px-5 py-3.5 bg-slate-50 border border-slate-100 rounded-2xl text-sm focus:ring-4 focus:ring-blue-500/10 outline-none transition-all resize-none"
                  />
                </div>
              </div>
              <div className="flex justify-end gap-3 pt-2">
                <button 
                  onClick={() => setShowCreateModal(false)}
                  className="px-6 py-2.5 bg-white border border-slate-200 text-slate-500 rounded-xl text-sm font-bold hover:bg-slate-50 transition-all"
                >
                  取消
                </button>
                <button 
                  disabled={!newKBName || !newKBDesc}
                  onClick={handleCreateKB}
                  className="px-8 py-2.5 bg-blue-600 text-white rounded-xl text-sm font-bold shadow-lg shadow-blue-100 hover:bg-blue-700 disabled:opacity-50 transition-all"
                >
                  立即创建
                </button>
              </div>
            </div>
          )}

          {showRenameModal && (
            <div className="bg-white rounded-[32px] w-full max-w-md p-8 shadow-2xl animate-in zoom-in-95 duration-300 flex flex-col gap-6" onClick={(e) => e.stopPropagation()}>
               <div className="flex items-center justify-between">
                <h2 className="text-xl font-bold text-slate-800">重命名知识库</h2>
                <button onClick={() => setShowRenameModal(null)} className="p-2 hover:bg-slate-50 rounded-xl transition-all"><X size={20}/></button>
              </div>
              <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-400 uppercase tracking-widest">新名称</label>
                  <input 
                    type="text" 
                    value={renameValue}
                    onChange={(e) => setRenameValue(e.target.value)}
                    className="w-full px-5 py-3.5 bg-slate-50 border border-slate-100 rounded-2xl text-sm focus:ring-4 focus:ring-blue-500/10 outline-none transition-all"
                  />
              </div>
              <div className="flex justify-end gap-3 pt-2">
                <button onClick={() => setShowRenameModal(null)} className="px-6 py-2.5 bg-white border border-slate-200 text-slate-500 rounded-xl text-sm font-bold hover:bg-slate-50 transition-all">取消</button>
                <button onClick={handleRenameKB} className="px-8 py-2.5 bg-blue-600 text-white rounded-xl text-sm font-bold shadow-lg shadow-blue-100 hover:bg-blue-700 transition-all">确认重命名</button>
              </div>
            </div>
          )}

          {showCreatorId && (
            <div className="bg-white rounded-[32px] w-full max-w-md p-8 shadow-2xl animate-in zoom-in-95 duration-300 flex flex-col gap-6" onClick={(e) => e.stopPropagation()}>
               <div className="flex items-center justify-between">
                <h2 className="text-xl font-bold text-slate-800">知识库创建人</h2>
                <button onClick={() => setShowCreatorId(null)} className="p-2 hover:bg-slate-50 rounded-xl transition-all"><X size={20}/></button>
              </div>
              <div className="flex items-center gap-4 bg-slate-50 p-6 rounded-3xl border border-slate-100">
                <div className="w-14 h-14 bg-white rounded-2xl flex items-center justify-center text-blue-600 shadow-sm border border-slate-200">
                  <User size={28} />
                </div>
                <div>
                   <p className="text-sm font-black text-slate-800">{workspaces.find(k => k.id === showCreatorId)?.owner}</p>
                   <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mt-0.5">创建于 {workspaces.find(k => k.id === showCreatorId)?.lastUpdated}</p>
                </div>
              </div>
              <button onClick={() => setShowCreatorId(null)} className="w-full py-3 bg-slate-900 text-white rounded-2xl text-sm font-bold hover:bg-slate-800 transition-all shadow-lg">关闭窗口</button>
            </div>
          )}
        </div>
      )}

      {/* Tab Selector */}
      <div className="flex items-center justify-between">
        <div className="flex bg-white p-1 rounded-2xl border border-slate-200 shadow-sm">
          <button 
            onClick={() => setActiveTab('qa')}
            className={`flex items-center gap-2 px-6 py-2 rounded-xl text-sm font-bold transition-all ${activeTab === 'qa' ? 'bg-blue-600 text-white shadow-lg shadow-blue-100' : 'text-slate-500 hover:bg-slate-50'}`}
          >
            <MessageSquare size={16} /> 智能对话
          </button>
          <button 
             onClick={() => {
               setActiveTab('management');
               setMgmtView('kb-list');
             }}
            className={`flex items-center gap-2 px-6 py-2 rounded-xl text-sm font-bold transition-all ${activeTab === 'management' ? 'bg-slate-800 text-white shadow-lg shadow-slate-200' : 'text-slate-500 hover:bg-slate-50'}`}
          >
            <Library size={16} /> 知识库管理
          </button>
        </div>

        <div className="flex items-center gap-4">
          <div className="hidden lg:flex items-center gap-2 px-3 py-1.5 bg-slate-100 rounded-full border border-slate-200">
            <Zap size={14} className="text-blue-500"/>
            <span className="text-[10px] font-bold text-slate-600">RAG 向量引擎已就绪</span>
          </div>
          <button className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-xl text-xs font-bold hover:bg-blue-700 transition-all shadow-lg shadow-blue-100">
            <Upload size={14}/> 导入新知识
          </button>
        </div>
      </div>

      <div className="flex-1 flex gap-6 overflow-hidden">
        {/* Sidebar */}
        {activeTab === 'qa' && (
          <div className="w-80 flex flex-col gap-4 overflow-y-auto pr-2 scrollbar-hide shrink-0 animate-in slide-in-from-left-4">
            {/* Knowledge Selection */}
            <div className="bg-white rounded-[32px] border border-slate-200 shadow-sm flex flex-col overflow-hidden shrink-0">
              <div className="p-5 border-b border-slate-100 bg-slate-50/50">
                <div className="flex items-center justify-between mb-1">
                  <h3 className="text-sm font-bold text-slate-800">当前对话源</h3>
                  <Settings2 size={14} className="text-slate-400" />
                </div>
              </div>
              
              <div className="p-3 space-y-2">
                {workspaces.map(kb => {
                  const isSelected = selectedKBIds.includes(kb.id);
                  return (
                    <div 
                      key={kb.id}
                      onClick={() => toggleKBSelection(kb.id)}
                      className={`group flex items-center gap-3 p-3 rounded-2xl border cursor-pointer transition-all ${
                        isSelected ? 'bg-blue-50 border-blue-200 shadow-inner' : 'bg-white border-transparent hover:bg-slate-50'
                      }`}
                    >
                      <div className={`w-10 h-10 rounded-xl flex items-center justify-center transition-all ${
                        isSelected ? `${kb.color} text-white shadow-lg` : 'bg-slate-100 text-slate-400'
                      }`}>
                        <Library size={18} />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className={`text-xs font-bold truncate ${isSelected ? 'text-blue-900' : 'text-slate-700'}`}>{kb.name}</p>
                        <p className="text-[9px] text-slate-400 font-medium">{kb.fileCount} 份文档</p>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* History Sessions List */}
            <div className="flex-1 bg-white rounded-[32px] border border-slate-200 shadow-sm flex flex-col overflow-hidden">
              <div className="p-5 border-b border-slate-100 bg-slate-50/50 flex items-center justify-between">
                <h3 className="text-sm font-bold text-slate-800 flex items-center gap-2">
                  <History size={16} className="text-slate-400" /> 历史会话记录
                </h3>
                <button className="p-1.5 hover:bg-slate-200 rounded-lg transition-colors"><Plus size={14}/></button>
              </div>
              <div className="flex-1 overflow-y-auto p-3 space-y-2 scrollbar-hide">
                {chatHistory.map((history) => (
                  <div key={history.id} className="p-4 rounded-2xl bg-slate-50/50 border border-transparent hover:border-blue-100 hover:bg-blue-50/30 transition-all cursor-pointer group">
                    <p className="text-xs font-bold text-slate-700 group-hover:text-blue-600 truncate mb-1">{history.title}</p>
                    <div className="flex items-center gap-2 text-[9px] font-bold text-slate-400 uppercase tracking-widest">
                       <Clock size={10} /> {history.date}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Main View Area */}
        <div className="flex-1 min-w-0 overflow-y-auto scrollbar-hide">
          {activeTab === 'qa' ? (
            <div className="h-full flex flex-col bg-white rounded-[32px] border border-slate-200 shadow-sm relative overflow-hidden">
              <div className="h-12 border-b border-slate-100 px-6 flex items-center justify-between bg-slate-50/30">
                <div className="flex items-center gap-3">
                  <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">
                    {selectedKBIds.length > 0 ? `活跃知识源: ${selectedKBIds.length} 个库` : '未激活知识源'}
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-[10px] text-slate-300 font-bold uppercase tracking-widest">震慑 RAG 引擎 v2.0</span>
                </div>
              </div>

              <div className="flex-1 overflow-y-auto p-8 space-y-6">
                {messages.map((m, i) => (
                  <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                    <div className={`max-w-[85%] p-5 rounded-[24px] ${
                      m.role === 'user' 
                        ? 'bg-blue-600 text-white shadow-xl shadow-blue-50' 
                        : 'bg-slate-50 border border-slate-100 text-slate-700'
                    }`}>
                      <p className="text-sm leading-relaxed whitespace-pre-wrap">{m.content}</p>
                    </div>
                  </div>
                ))}
              </div>

              <div className="p-6 bg-slate-50/50 border-t border-slate-100">
                <div className="relative max-w-4xl mx-auto">
                  <input
                    type="text"
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                    placeholder="请输入业务查询指令，AI 将基于已选知识库进行深度分析..."
                    className="w-full pl-6 pr-16 py-5 bg-white border border-slate-200 rounded-[24px] text-sm focus:ring-4 focus:ring-blue-500/10 outline-none transition-all shadow-sm"
                  />
                  <button 
                    onClick={handleSend}
                    className="absolute right-3 top-1/2 -translate-y-1/2 p-3 bg-blue-600 text-white rounded-2xl hover:bg-blue-700 transition-all shadow-lg active:scale-95"
                  >
                    <ChevronRight size={20} />
                  </button>
                </div>
              </div>
            </div>
          ) : (
            <div className="h-full">
              {mgmtView === 'kb-list' && renderKBList()}
              {mgmtView === 'doc-list' && renderDocList()}
              {mgmtView === 'chunk-view' && renderChunkView()}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
